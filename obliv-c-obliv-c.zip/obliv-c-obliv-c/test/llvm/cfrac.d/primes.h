extern unsigned int primesize;
extern unsigned short primes[];
