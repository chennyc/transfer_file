#include <stdio.h>

char *s = "fun";

int main(int argc, char **argv)
{
  printf("hello world %d %d %d\n", s[0], s[1], s[3]);
  return 0;
}
