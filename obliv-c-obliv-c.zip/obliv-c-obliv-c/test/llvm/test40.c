#include <stdio.h>
#include <wchar.h>

int main(int argc, char **argv)
{
  wprintf(L"hello world\n");
  return 0;
}
