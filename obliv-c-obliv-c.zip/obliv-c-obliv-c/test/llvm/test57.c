#include <stdio.h>

float a = 3;

int main(int argc, char **argv)
{
  printf("hello world %g\n", a);
  return 0;
}
