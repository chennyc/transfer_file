Specialized gates for swapping when swap/noswap control bits are known to one party in plain text.
