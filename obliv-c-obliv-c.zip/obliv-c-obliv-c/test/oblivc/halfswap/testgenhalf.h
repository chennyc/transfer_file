#pragma once

typedef struct
{
  int n;
  int* data;
}TestGenHalfIO ;

void testGenHalf(void* vargs);
