#pragma once

#define MAXN 100

typedef struct protocolIO
{ const char* s;
  int n;
  int res;
} protocolIO;

void hammingDistance(void* args);
