// __inline__ void testit ( int flag )
// {
//         ;
// }

extern void testit ( int flag );

void otest(int flag)
{
        testit(flag);
}
