typedef int ptrdiff_t;
typedef int FILE;

__inline static char equal___0(void);

__inline static void _M_getc___0(void);

__inline static ptrdiff_t theFunc___0 (FILE const *__20468_44___f);


__inline static int sgetc___0(void) {
  theFunc___0 (0);
}

__inline static char equal___0(void) {
  _M_getc___0();
  return 0;
}

__inline static void _M_getc___0(void) {
  sgetc___0 ();
  return;
}

__inline static ptrdiff_t theFunc___0 (FILE const *__20468_44___f) {

}


int main()
{
  theFunc___0(0);
  return 0;
}
