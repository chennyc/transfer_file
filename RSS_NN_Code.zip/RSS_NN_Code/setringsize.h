// typedef __uint128_t Lint; // for ring size in [63,126];
typedef unsigned long long Lint; // for ring size in [1,62]; change to unsigned
