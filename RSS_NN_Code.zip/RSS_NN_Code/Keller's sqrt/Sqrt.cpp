/*
The code in this folder is mainly taken from https://github.com/rdragos/MP-SPDZ, which is maintained by Keller's team

This code requires gmp library


*/


#include "Z2K.h"

#include <iostream>
void Z2::seta(int i)
{
	a[0]=i;

}

Z2& Z2::operator+=(const Z2& other)
{
	mpn_add_fixed_n<N_WORDS>(a, other.a, a);
	a[N_WORDS - 1] &= UPPER_MASK;
	return *this;
}

Z2 Z2::operator=(int i)
{
	printf("hi\n");
	printf("%d\n",i);
	Z2 res;
	res.seta(i);
	res.print_limb();
	return res;
}


Z2 Z2::operator-(const Z2& other) const
{
	Z2 res;
	mpn_sub_fixed_n<N_WORDS>(res.a, a, other.a);
	res.a[N_WORDS - 1] &= UPPER_MASK;
	return res;
}


Z2 Z2::operator<<(int i) const
{
	Z2 res;
	int n_limb_shift = i / N_LIMB_BITS;
	for (int j = n_limb_shift; j < N_WORDS; j++)
		res.a[j] = a[j - n_limb_shift];
	int n_inside_shift = i % N_LIMB_BITS;
	if (n_inside_shift > 0)
		mpn_lshift(res.a, res.a, N_WORDS, n_inside_shift);
	res.a[N_WORDS - 1] &= UPPER_MASK;
	return res;
}

bool Z2::get_bit(int i) const
{
	return 1 & (a[i / N_LIMB_BITS] >> (i % N_LIMB_BITS));
}


inline Z2 Z2::Mul(const Z2& x, const Z2& y)
{
	Z2 res;
	mpn_mul_fixed_<N_WORDS, Z2::N_WORDS, Z2::N_WORDS>(res.a, x.a, y.a);
	res.a[N_WORDS - 1] &= UPPER_MASK;
	return res;
}


Z2 Z2::sqrRoot()
{
	print_limb();
	printf("hiii\n");
	assert(a[0] % 8 == 1);
	Z2 res;
	Z2 res2;
	//res = 1;
	res.seta(1);
	bool d;
	for (int i = 0; i < K - 1; i++)
	{
		printf("i=%d  ",i);
		d=(*this - Z2::Mul(res, res)).get_bit(i + 1);

		if(d)
		{
			printf("1\n");
		}
		else
		{
			printf("0\n");
		}		

		res += Setbit_Z2(d) << i;
	}
	return res;
}

using namespace std;

int main()
{
	Z2 x;
	double square;
	cout<<"Please input the square\n"<< endl;
	cin>>square;
	x.seta(square);
	x.print_limb();
	Z2 res=x.sqrRoot();
	cout<<"Sqr is:";
	res.print_limb();
	return 0;
}
