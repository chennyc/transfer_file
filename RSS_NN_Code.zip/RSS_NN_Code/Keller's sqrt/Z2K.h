#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <gmp.h> 
#include <assert.h>
#include "mpn_fixed.h"
#define K 64
#define L 64
#define M 64


class Z2
{
protected:


	static const int N_WORDS = ((K + 7) / 8 + sizeof(mp_limb_t) - 1)
			/ sizeof(mp_limb_t);
	static const int N_LIMB_BITS = 8 * sizeof(mp_limb_t);
	static const uint64_t UPPER_MASK = uint64_t(-1LL) >> (N_LIMB_BITS - 1 - (K - 1) % N_LIMB_BITS);
	mp_limb_t a[N_WORDS];

public:
	void seta(int i);

	void print_limb()
	{

	gmp_printf("limb %Mu\n", a[0]);
	}

	Z2 Setbit_Z2(bool i)
	{
		Z2 res;
//		mpz_t integer;
//		mpz_init(integer);
//		mp_size_t x;
	
		if (i==0)
		{
//			mpz_set_ui(integer,0);
//			x=mpz_size(integer);
			//res.a=mpz_limbs_write(integer,x);
			res.a[0]=0;
		}
		else
		{

//			mpz_set_ui(integer,1);
//			x=mpz_size(integer);
			//res.a=mpz_limbs_write(integer,x);
			res.a[0]=1;
		}
//		mpz_clear(integer);
	return res;
	}
	/*
	typedef void Inp;
	typedef void PO;
	typedef void Square;

	class DummyZ2kProtocol
	{
	public:
	    static void assign(Z2& _,  const Z2& __, int& ___)
        {
            (void) _, (void) __, (void) ___;
            throw not_implemented();
        }
	};
	typedef DummyZ2kProtocol Protocol;

	static const int N_BITS = K;
	static const int N_BYTES = (K + 7) / 8;

	static int size() { return N_BYTES; }
	static int size_in_limbs() { return N_WORDS; }
	static int t() { return 0; }

	static char type_char() { return 'R'; }
	static string type_string() { return "Z2^" + to_string(int(N_BITS)); }

	static DataFieldType field_type() { return DATA_INT; }

	static const bool invertible = false;
	*/


	static Z2 Mul(const Z2& x, const Z2& y); //needed

	/*
	static void reqbl(int n);
	static bool allows(Dtype dtype);

	typedef Z2 next;

	Z2() { assign_zero(); }
	Z2(uint64_t x) : Z2() { a[0] = x; }
	Z2(__m128i x) : Z2() { avx_memcpy(a, &x, min(N_BYTES, 16)); }
	Z2(int x) : Z2(long(x)) { a[N_WORDS - 1] &= UPPER_MASK; }
	Z2(long x) : Z2(uint64_t(x)) { if (K > 64 and x < 0) memset(&a[1], -1, N_BYTES - 8); }
	Z2(const Integer& x);
	Z2(const bigint& x);
	Z2(const void* buffer) : Z2() { assign(buffer); }
	template <int L>
	Z2(const Z2<L>& x) : Z2()
	{ avx_memcpy(a, x.a, min(N_BYTES, x.N_BYTES)); normalize(); }

	void normalize() { a[N_WORDS - 1] &= UPPER_MASK; }

	void assign_zero() { avx_memzero(a, sizeof(a)); }
	void assign_one()  { assign_zero(); a[0] = 1; }
	void assign(const void* buffer) { avx_memcpy(a, buffer, N_BYTES); normalize(); }
	void assign(int x) { *this = x; }

	mp_limb_t get_limb(int i) const { return a[i]; }
	*/	
	
	bool get_bit(int i) const; //needed

	/*
	const void* get_ptr() const { return a; }
	const mp_limb_t* get() const { return a; }

	void convert_destroy(bigint& a) { *this = a; }

	void negate() { 
		throw not_implemented();
	}
	
	Z2<K> operator+(const Z2<K>& other) const;
	*/
	Z2 operator-(const Z2& other) const;
	/*
	template <int L>
	Z2<K+L> operator*(const Z2<L>& other) const;

	Z2<K> operator*(bool other) const { return other ? *this : Z2<K>(); }

	Z2<K> operator/(const Z2& other) const { (void) other; throw not_implemented(); }
	*/

	Z2& operator+=(const Z2& other); //needed
	Z2 operator<<(int i) const;
	Z2 operator=(int i);
	/*
	Z2<K>& operator-=(const Z2<K>& other);


	Z2<K> operator>>(int i) const;

	bool operator==(const Z2<K>& other) const;
	bool operator!=(const Z2<K>& other) const { return not (*this == other); }

	void add(const Z2<K>& a, const Z2<K>& b) { *this = a + b; }
	void add(const Z2<K>& a) { *this += a; }
	void sub(const Z2<K>& a, const Z2<K>& b) { *this = a - b; }
	*/
	

	void mul(const Z2& a, const Z2& b) { *this = Z2::Mul(a, b); } //needed
	//void mul(const Integer& a, const Z2<L>& b) { *this = Z2<K>::Mul(Z2<64>(a), b); } //needed

	void mul(const Z2& a) { *this = Z2::Mul(*this, a); } //needed
	Z2 sqrRoot();
	/*
	template <int t>
	void add(octetStream& os) { add(os.consume(size())); }

	Z2& invert();
	void invert(const Z2& a) { *this = a; invert(); }



	bool is_zero() const { return *this == Z2<K>(); }
	bool is_one() const { return *this == 1; }
	bool is_bit() const { return is_zero() or is_one(); }

	void SHL(const Z2& a, const bigint& i) { *this = a << i.get_ui(); }
	void SHR(const Z2& a, const bigint& i) { *this = a >> i.get_ui(); }

	void AND(const Z2& a, const Z2& b);
	void OR(const Z2& a, const Z2& b);
	void XOR(const Z2& a, const Z2& b);

	void randomize(PRNG& G);
	void almost_randomize(PRNG& G) { randomize(G); }

	void force_to_bit() { throw runtime_error("impossible"); }

	void pack(octetStream& o) const;
	void unpack(octetStream& o);

	void input(istream& s, bool human=true);
	void output(ostream& s, bool human=true) const;

	template <int J>
	friend ostream& operator<<(ostream& o, const Z2<J>& x);
	*/
};

