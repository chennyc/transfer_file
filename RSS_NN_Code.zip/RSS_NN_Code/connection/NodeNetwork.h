/*   
   PICCO: A General Purpose Compiler for Private Distributed Computation
   ** Copyright (C) 2013 PICCO Team
   ** Department of Computer Science and Engineering, University of Notre Dame

   PICCO is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   PICCO is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with PICCO. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef NODENETWORK_H_
#define NODENETWORK_H_
#include "NodeConfiguration.h"
#include <cstring>
#include <vector>
#include <cstdlib>
#include <map>
#include <openssl/evp.h>
#include <openssl/aes.h>

#include <stdio.h>
#include <unistd.h>
#include <stdint.h>     //for int8_t
#include <string.h>     //for memcmp
#include <tmmintrin.h>
#include <wmmintrin.h>  //for intrinsics for AES-NI
#include <inttypes.h>

#define KE2(NK,OK,RND) NK = OK; \
    NK = _mm_xor_si128(NK, _mm_slli_si128(NK, 4));  \
    NK = _mm_xor_si128(NK, _mm_slli_si128(NK, 4));  \
    NK = _mm_xor_si128(NK, _mm_slli_si128(NK, 4));  \
    NK = _mm_xor_si128(NK, _mm_shuffle_epi32(_mm_aeskeygenassist_si128(OK, RND), 0xff));


class NodeNetwork {
public:
	NodeNetwork(NodeConfiguration *nodeConfig, std::string privatekey_filename, int num_threads, int ring_size);
	NodeNetwork();
	virtual ~NodeNetwork();

	//Send round data to a specific peer
	void sendDataToPeer(int, Lint*, int, int, int, int);
        void sendDataToPeer(int, int, int*);
	void sendDataToPeer(int, int, unsigned char*);
	void sendDataToPeer(int, int, Lint*, int); 
	//void sendDataToPeer(int, int, long long*); 
	void sendModeToPeers(int); 
	//Get round data from a specific peer
	void getDataFromPeer(int, Lint*, int, int, int, int);
	void getDataFromPeer(int, int, int*);
	void getDataFromPeer(int, int, unsigned char*);
        void getDataFromPeer(int, int, Lint*, int);
        //void getDataFromPeer(int, int, long long*);

	void SendAndGetDataFromPeer(int, int, Lint*, Lint*, int, int);

	void getDataFromPeer(Lint*, int, int, int); //Add for 3P lookup
	void sendDataToPeer_T(int, Lint*, int, int);
	void multicastToPeers(Lint** , Lint** , int, int);



	//Broadcast identical data to peers
	//	void broadcastToPeers(mpz_t*, int, mpz_t**);
	//	void broadcastToPeers(long long*, int, long long**); 
	//	void multicastToPeers(mpz_t**, mpz_t**, int);
//	void multicastToPeers(long long**, long long**, int); 

	//Get the ID of the compute Node
	int getID();
	int getNumOfThreads(); 
	void getRounds(int, int*, int*, int); 
	//void handle_write(const boost::system::error_code& error);
	//Close all the connections to peers
	void closeAllConnections();

	//Encryption and Decryption
	void init_keys(int peer, int nRead);
	void gen_keyiv();
	void get_keyiv(char* key_iv);
	unsigned char *aes_encrypt(EVP_CIPHER_CTX *e, unsigned char *plaintext, int *len);
	unsigned char *aes_decrypt(EVP_CIPHER_CTX *e, unsigned char *ciphertext, int *len);
	
	//Close
	//void mpzFromString(char*, mpz_t*, int*, int);
	double time_diff(struct timeval *, struct timeval *);




	//PRG
	void prgtest();
	__m128i * prg_keyschedule(uint8_t *);
	void prg_aes(uint8_t *, uint8_t *, __m128i *);
	void prg_setup();
	void prg_clean();
	void prg_getrandom(int keyID, int size, Lint* dest);

	//
	//int getbytes();
	int getringsize();
private:

	static int mode; 
	static int numOfChangedNodes; 
	static int isManagerAwake; 
 
	int numOfThreads; 
	void connectToPeers();
	void requestConnection(int); 
	void acceptPeers(int); 
	std::map<int, int> peer2sock;  
	std::map<int, int> sock2peer; 
	int serverSock;

	uint8_t **random_container;
	int container_size;
	int *P_container;
	__m128i ** prg_key;
	
	//int bytes;
	int ringsize;

};

#endif /* NODENETWORK_H_ */
