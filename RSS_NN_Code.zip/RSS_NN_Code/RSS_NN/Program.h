#ifndef Program_H_
#define Program_H_
#include <stdio.h>
#include <iostream>
#include "sys/time.h"
#include "Rss_Op.h"
extern "C"{
#include "aes_ni.h"
}
void test(NodeNetwork*, NodeConfiguration*, int);
void test2(NodeNetwork *nNet, NodeConfiguration *nodeConfig, int size);
#endif
