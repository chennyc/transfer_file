#include "Rss_Op.h"
extern "C"{
#include "aes_ni.h"
}

Lint bitExtracted(Lint a, int k)
//https://www.geeksforgeeks.org/extract-k-bits-given-position-number/
//output k least significant bits of a;  This function should be called when we need to open a value
{
	return (((Lint(1) << k) - Lint(1)) & a);   
} 

void Rss_Open(Lint *res, Lint **a, int size, int *map, int r_size, NodeNetwork *nodeNet) 
//a[0] will be sent to next neighbor map[0], res will be filled by the received value from map[1]
//the r_size in the functions that including open functionality (open_s, multpub) refers to the ring size that we are doing computation over, this might be different from the basic ring_size. E.g., in randbits, multpub is working over ring_size+2.
{
	//communication
	int bytes = 0, ring_size = r_size;
	bytes = (ring_size+8-1)/8;
	nodeNet->SendAndGetDataFromPeer(map[0], map[1], a[1], res, size, bytes);
	for(int i = 0; i<size; i++){
		res[i] = a[0][i] + a[1][i] + res[i];
		res[i] = bitExtracted(res[i],ring_size);

	}
}

void Rss_Open_s(Lint *res, Lint *a_0, Lint* a_1, int size, int *map, int r_size, NodeNetwork *nodeNet) 
//a[0] will be sent to next neighbor map[0], res will be filled by the received value from map[1]
{
	int bytes = 0, ring_size = r_size;
	bytes = (ring_size+8-1)/8;

	//communication
	nodeNet->SendAndGetDataFromPeer(map[0], map[1], a_1, res, size, bytes);
	for(int i = 0; i<size; i++){
		res[i] = a_0[i] + a_1[i] + res[i];
		res[i] = bitExtracted(res[i],ring_size);
	}

}

void Rss_Mult(Lint** c, Lint** a, Lint** b, int size, int *map, NodeNetwork *nodeNet) 
	
//	For party 1, a[0,1]=a_2,3; b[0,1]=b_2,3;  c[0,1] = c_2,3;
//	For party 2, a[0,1]=a_3,1; b[0,1]=b_3,1;  c[0,1] = c_3,1;
//	For party 3, a[0,1]=a_1,2; b[0,1]=b_1,2;  c[0,1] = c_1,2;
	
{
	int bytes = 0, ring_size = nodeNet->getringsize();
	bytes = (ring_size+8-1)/8;

 	Lint *v = new Lint [size];
	memset(v,0,sizeof(Lint)*size);

 	Lint *v_a = new Lint [size];
	memset(v_a,0,sizeof(Lint)*size);

 	Lint *v_b = new Lint [size];
	memset(v_b,0,sizeof(Lint)*size);

	for(int i = 0 ; i<size; i++){
		v[i] = a[0][i] * b[0][i] + a[0][i] * b[1][i] + a[1][i] * b[0][i];
		nodeNet->prg_getrandom(1, bytes, v_b+i);
		v_a[i] = v[i] - v_b[i];
	}
	
	//communication
	nodeNet->SendAndGetDataFromPeer(map[0], map[1], v_a, c[1], size, bytes);

	for(int i = 0; i<size; i++){
		nodeNet->prg_getrandom(0, bytes, c[0]+i);
		c[0][i] = c[0][i] + v_a[i];
		c[1][i] = c[1][i] + v_b[i];
	}


	//free
	delete [] v;
	delete [] v_a;
	delete [] v_b;

}



void Rss_RandBit(Lint** b, int size, int *map, NodeNetwork* nodeNet){

	int pid = nodeNet->getID();
	int ring_size = nodeNet->getringsize();

	int bytes = (ring_size+2+8-1)/8;

	Lint **u = new Lint *[2];
	Lint **a = new Lint *[2];
	Lint **d = new Lint *[2];
	
	for(int i = 0; i < 2; i++){
		u[i] = new Lint [size];
		memset(u[i],0,sizeof(Lint)*size);
		a[i] = new Lint [size];
		memset(a[i],0,sizeof(Lint)*size);
		d[i] = new Lint [size];
		memset(d[i],0,sizeof(Lint)*size);
	}

	Lint *e = new Lint [size];
	memset(e,0,sizeof(Lint)*size);
 	Lint *c = new Lint [size];
	memset(c,0,sizeof(Lint)*size);

	for(int i = 0 ; i<size; i++){ 

		// generating random shares in Z_2^k+2 
		nodeNet->prg_getrandom(0, bytes, u[0]+i); 
		nodeNet->prg_getrandom(1, bytes, u[1]+i); 

	}

	// used to make a odd, we only add 1 to one share of a
	// All shares will be doubled
	Lint a1 = 0;
	Lint a2 = 0;
	switch(pid){
		case 1:
		  a1 = 1;
		  a2 = 0;
			break;
		case 2:
		  a1 = 0;
		  a2 = 0;
			break;
		case 3:
		  a1 = 0;
		  a2 = 1;
			break;
	}


	for(int i = 0 ; i<size; i++){
		
		// ensuring [a] is odd
	  	a[0][i] = Lint(Lint(2)*u[0][i] + a1); 
	  	a[1][i] = Lint(Lint(2)*u[1][i] + a2); 

	}

 		
	// squaring a
	Rss_MultPub(e, a, a, size, map, ring_size+2, nodeNet);

	// calculating the smallest root of e 
	rss_sqrt(c, e, size, ring_size);

	// inverting c
	invert(c, c, size, ring_size+2);	



	for(int i = 0 ; i<size; i++){

		// shares of d will be even
		d[0][i] = c[i]*a[0][i] + a1;
		d[1][i] = c[i]*a[1][i] + a2;


	}	

	for(int i = 0 ; i<size; i++){
	  
		// equivalent to dividing by 2
		b[0][i] = d[0][i] >> 1; 
		b[1][i] = d[1][i] >> 1; 
	
	}	

	// freeing up
	delete [] c;
	delete [] e;

	for(int i = 0; i < 2; i++){

		delete [] d[i];
		delete [] a[i];
		delete [] u[i];

	}

	delete [] d;
	delete [] a;
	delete [] u;	

}

// invert a
// dest : c
void invert(Lint *c, Lint *a, int size, int ring_size){

	// note, should really check if a is odd
	// if even abort

	for (int i = 0; i < size; i++) {
  		Lint res = 1;
		
	    for (int j = 0; j < ring_size; j++) {
	        // res += {Z2<K>((Z2<K>(1) - Z2<K>::Mul(*this, res)).get_bit(j)) << j};

	    	Lint temp = Lint(1) - a[i]*res;

			// https://codeforwin.org/2016/01/c-program-to-get-value-of-nth-bit-of-number.html
	    	// b = temp.get_bit(j)
	    	temp = (temp >> j) & Lint(1); // getting the jth bit

	    	res += (temp << j);
	    }
	    c[i] = res;
	}
}

unsigned countBits(Lint number) {
      // log function in base 2  
      // take only integer part 
      return (int)log2(number)+1; 
} 


void rss_sqrt(Lint *c, Lint *e, int size, int ring_size){

	// calculates the smallest root of some 

	for(int i = 0 ; i <size; i++){


		// make sure e[i] is odd square
		assert(e[i] % Lint(8) == Lint(1)); 		
		//printf("e[%i] %u\n", i, e[i]);

		// the least significant bit of the root must be 1
		c[i] = 1; 
		Lint d_ = 0;
		//printf("c:");
		for (int j = 0; j < ring_size+1; j++) {
			
			Lint temp = Lint(0);
			
			temp = e[i] - Lint(c[i])*Lint(c[i]);
			
			//printf("%d th temp: %u \n", j, temp);
			if(temp == 0ll)
			{
				//printf("stop\n");
				break;
			} 
			// d will be the j-th (j>0) least significant bit of the root
			d_ = (temp >> (j+1) ) & 1; //getting the jth+1 bit
			//printf("%d th d: %u \n", j, d_);
			// left shift d for j bits and add it to res; 
			c[i] += (d_ << j);
			//printf("%d th c: %u \n", j, c[i]);
		}
		//printf("\nc[%i] %u\n", i, c[i]);
		//printf("c[%i]square is  %u\n", i, c[i]*c[i]); // c^2 should equal to e
	// 	printf("bits of c[%i] %i\n", i, countBits(c[i]));
	// 	res[i] = c[i];
	}	


}


void Rss_MultPub(Lint * c, Lint** a, Lint** b, int size, int *map, int r_size, NodeNetwork* nodeNet) 
//	For party 1, a[0,1]=a_2,3; b[0,1]=b_2,3;  c[0,1] = c_2,3;
//	For party 2, a[0,1]=a_3,1; b[0,1]=b_3,1;  c[0,1] = c_3,1;
//	For party 3, a[0,1]=a_1,2; b[0,1]=b_1,2;  c[0,1] = c_1,2;
	
{

	int bytes = 0, ring_size = r_size;
	bytes = (ring_size+8-1)/8;

	Lint **sendbuf = new Lint *[3];
	Lint **recvbuf = new Lint *[3];
	for(int i = 0; i< 3; i++){
		sendbuf[i] = new Lint [size];
		memset(sendbuf[i],0,sizeof(Lint)*size);
		recvbuf[i] = new Lint [size];
		memset(recvbuf[i],0,sizeof(Lint)*size);
	}

	int pid = nodeNet->getID();

 	Lint *v = new Lint [size];
	memset(v,0,sizeof(Lint)*size);

 	Lint *v_a = new Lint [size];
	memset(v_a,0,sizeof(Lint)*size);

 	Lint *v_b = new Lint [size];
	memset(v_b,0,sizeof(Lint)*size);

	int opa = 0;
	int opb = 0;
	switch(pid){
		case 1:
			opa = 1;
			opb = 1;
			break;
		case 2:
			opa = -1;
			opb = 1;
			break;
		case 3:
			opa = -1;
			opb = -1;
			break;
	}
	for(int i = 0; i<size; i++){
		v[i] = a[0][i] * b[0][i] + a[0][i] * b[1][i] + a[1][i] * b[0][i];
		nodeNet->prg_getrandom(1, bytes, v_b+i);
		nodeNet->prg_getrandom(0, bytes, v_a+i);
		c[i] = v[i] + Lint(opb)*v_b[i] + Lint(opa)*v_a[i];
	}
	
	//communication
	//move data into buf
	for(int i = 1; i<= 3; i++){
		if(i == pid) continue;
		memcpy(sendbuf[i-1],c, sizeof(Lint)*size);
	}

	nodeNet->multicastToPeers(sendbuf, recvbuf, size, bytes);

	memcpy(v_a, recvbuf[map[0]-1], sizeof(Lint)*size);
	memcpy(v_b, recvbuf[map[1]-1], sizeof(Lint)*size);

	for(int i = 0; i<size; i++){
		c[i] = c[i] + v_a[i] + v_b[i];
		// printf("c[%i] : %u\n", i, c[i]);
		c[i] = bitExtracted(c[i],ring_size);
	}

	//free
	delete [] v;
	delete [] v_a;
	delete [] v_b;

	for(int i = 0; i< 3; i++){
		delete [] sendbuf[i];
		delete [] recvbuf[i];
	}
	delete [] sendbuf;
	delete [] recvbuf;

}

void test_rssop(){
	printf("hi");
}


void Rss_MatMult(Lint*** c, Lint*** a, Lint*** b, int m, int n, int s, int *map, NodeNetwork *nodeNet) 
//	[m][n] size matrix a; 	[n][s] size matrix b
//	For party 1, a[0,1]=a_2,3; b[0,1]=b_2,3;  c[0,1] = c_2,3;
//	For party 2, a[0,1]=a_3,1; b[0,1]=b_3,1;  c[0,1] = c_3,1;
//	For party 3, a[0,1]=a_1,2; b[0,1]=b_1,2;  c[0,1] = c_1,2;
	
{
	int bytes = 0, ring_size = nodeNet->getringsize();
	bytes = (ring_size+8-1)/8;

	Lint v, random = 0;
	Lint **v_a = new Lint *[m];
	Lint **v_b = new Lint *[m];
	for(int i = 0; i< m; i++){
		v_a[i] = new Lint [s];
		memset(v_a[i],0,sizeof(Lint)*s);
		v_b[i] = new Lint [s];
		memset(v_b[i],0,sizeof(Lint)*s);
	}


	Lint *send_buf = new Lint [m*s];
	memset(send_buf,0,sizeof(Lint)*m*s);
	Lint *recv_buf = new Lint [m*s];
	memset(recv_buf,0,sizeof(Lint)*m*s);

	for(int i = 0; i < m; i++){
		for(int j = 0; j < s; j++){
			for(int k = 0; k<n; k++){
			  v = a[0][i][k] * b[0][k][j] + a[0][i][k] * b[1][k][j] + a[1][i][k] * b[0][k][j];
			  v_a[i][j] += v;	
			}
			nodeNet->prg_getrandom(1, bytes, &random);
			v_a[i][j] = v_a[i][j] - random;
			v_b[i][j] = random;
			nodeNet->prg_getrandom(0, bytes, &random);
			c[0][i][j] = random;
		}
	}

	//send v_a
	for(int i = 0; i < m; i++){
		memcpy(send_buf+i*s, v_a[i], sizeof(Lint)*s);
	}
	nodeNet->SendAndGetDataFromPeer(map[0], map[1], send_buf, recv_buf, m*s, bytes);
	for(int i = 0; i < m; i++){
		memcpy(c[1][i], recv_buf+i*s, sizeof(Lint)*s);
	}
	for(int i = 0; i < m; i++){
		for(int j = 0; j < s; j++){
			c[0][i][j] = c[0][i][j] + v_a[i][j];
			c[1][i][j] = c[1][i][j] + v_b[i][j];
		}
	}
	//free
	delete [] send_buf;
	delete [] recv_buf;
	for(int i = 0; i< m; i++){
		delete [] v_a[i];
		delete [] v_b[i];
	}
	delete [] v_a;
	delete [] v_b;
}
