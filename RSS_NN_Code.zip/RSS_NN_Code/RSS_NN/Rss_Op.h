#ifndef RSS_OP_H_
#define RSS_OP_H_
#include <stdio.h>
#include <math.h>       /* pow */

#include "../sqrt/Z2K.h"
#include "../connection/NodeNetwork.h"

void Rss_Open(Lint *res, Lint **a, int size, int *map, int r_size, NodeNetwork *nodeNet);
void Rss_Open_s(Lint *res, Lint *a_0, Lint *a_1, int size, int *map, int r_size, NodeNetwork *nodeNet);
void Rss_Mult(Lint** c, Lint** a, Lint** b, int size, int *map, NodeNetwork *nodeNet);
void Rss_MultPub(Lint * c, Lint** a_a, Lint** b, int size, int *map, int r_size, NodeNetwork* nodeNet);
void Rss_RandBit(Lint** b, int size, int *map, NodeNetwork* nodeNet);
void test_rssop();
void Rss_MatMult(Lint*** c, Lint*** a, Lint*** b, int m, int n, int s, int *map, NodeNetwork *nodeNet);

void invert(Lint *c, Lint *a, int size, int ring_size);

void rss_sqrt(Lint *c, Lint *e, int size, int ring_size);

unsigned countBits(Lint number); 
Lint bitExtracted(Lint number, int k);
#endif
