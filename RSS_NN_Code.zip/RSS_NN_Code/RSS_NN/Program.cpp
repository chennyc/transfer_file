#include "Program.h"

bool checkbytes(Lint a, Lint b, int bytes){

	Lint temp_a = 0;
	Lint temp_b = 0;
	memcpy(&temp_a, &a, bytes);
	memcpy(&temp_b, &b, bytes);
	if(temp_a == temp_b){return true;}
	return false;
}

void test(NodeNetwork* nNet, NodeConfiguration* nodeConfig, int size){
	int bits;

	int pid = nodeConfig->getID();
	int flag = 0;

	int ring_size = nNet->getringsize(); 
	int bytes = (ring_size+2+8-1)/8;

	printf("size : %i\n", size);
	printf("bytes : %i\n", bytes);
	printf("ring_size: %i\n", ring_size);

	struct timeval start;
	struct timeval end;
	unsigned long timer;

	bits = nNet->getID();
	printf("hello, I am %d\n", pid);
	
	int map[2];
	switch(pid){
		case 1:
			map[0] = 3;
			map[1] = 2;
			break;
		case 2:
			map[0] = 1;
			map[1] = 3;
			break;
		case 3:
			map[0] = 2;
			map[1] = 1;
			break;
	}	

	//setup prg key (will be used by all parties, only for data makeup)
	__m128i * key_prg;
	uint8_t key_raw[]    = {0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};
	key_prg = offline_prg_keyschedule(key_raw);
	//setup prg seed(k1, k2, k3)
	uint8_t k1[] = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t k2[] = {0xa2, 0x34, 0x6f, 0x67, 0x10, 0x1b, 0x13, 0xa3, 0x56, 0x45, 0x90, 0xb2, 0x13, 0xe3, 0x23, 0x24};


	//make up data
	Lint **a;
	Lint **b;
	Lint **c;	// c = a op b
	Lint **d;
	a = new Lint *[2];
	b = new Lint *[2];
	c = new Lint *[2];
	d = new Lint *[2];
	c[0] = new Lint [size];
	memset(c[0],0,sizeof(Lint)*size);
	c[1] = new Lint [size];
	memset(c[1],0,sizeof(Lint)*size);
        d[0] = new Lint [size];
        memset(d[0],0,sizeof(Lint)*size);
        d[1] = new Lint [size];
        memset(d[1],0,sizeof(Lint)*size);



	Lint **Data1;
	Lint **Data2;

	Data1 = new Lint *[3];
	for(int i = 0; i< 3; i++){
		Data1[i] = new Lint [size];
		memset(Data1[i],0,sizeof(Lint)*size);
	}

	Data2 = new Lint *[3];
	for(int i = 0; i< 3; i++){
		Data2[i] = new Lint [size];
		memset(Data2[i],0,sizeof(Lint)*size);
	}

	for(int i =0; i<size;i++){
		prg_aes_ni(Data1[0]+i, k1, key_prg);
		prg_aes_ni(Data1[1]+i, k1, key_prg);
		prg_aes_ni(Data2[0]+i, k2, key_prg);
		prg_aes_ni(Data2[1]+i, k2, key_prg);
		Data1[2][i] = i - Data1[0][i] - Data1[1][i];
		Data2[2][i] = i - Data2[0][i] - Data2[1][i];
		// printf("Data[2][%i] : %i\n", i, Data2[2][i]);

	}


 	Lint *res = new Lint [size];
	memset(res,0,sizeof(Lint)*size);
 	Lint *res_check = new Lint [size];
	memset(res_check,0,sizeof(Lint)*size);
	//assign data

	Lint a1 = 0;
	Lint a2 = 0;
	switch(pid){
		case 1:
			a[0] = Data1[1];
			a[1] = Data1[2];
			b[0] = Data2[1];
			b[1] = Data2[2];
			a1 = 1;
			a2 = 0;
			break;
		case 2:
			a[0] = Data1[2];
			a[1] = Data1[0];
			b[0] = Data2[2];
			b[1] = Data2[0];
			a1 = 0;
			a2 = 0;
			break;
		case 3:
			a[0] = Data1[0];
			a[1] = Data1[1];
			b[0] = Data2[0];
			b[1] = Data2[1];
			a1 = 0;
			a2 = 1;
			break;
	}

	// computation test open:
	gettimeofday(&start,NULL); //start timer here
	Rss_Open(res, a, size, map, ring_size, nNet);
	gettimeofday(&end,NULL);//stop timer here
	printf("res[0] %u\n", res[0]);


	timer = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
	// printf("runtime for open with data size %d = %ld us\n", size, timer);

	//check open

	for(int i = 0; i < size; i++)
	{

		res_check[i] = Data1[0][i] + Data1[1][i] + Data1[2][i];
		// printf("res_check[i]: %u\n", res_check[i] );

		if(!checkbytes(res[i], res_check[i], bytes) && flag == 0)
		{
			printf("Open ERROR at %d !=   \n", i);
			print_1283(res[i]);
			print_1283(res_check[i]);
			flag = 1;
		}
	}
	if(flag == 0)	{
		printf("Open correct!\n");
	}


	
	//computation test Mult:
	gettimeofday(&start,NULL); //start timer here
	Rss_Mult(c, a, b, size, map, nNet);
	gettimeofday(&end,NULL);//stop timer here

	timer = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
	printf("runtime for mult with data size %d = %ld us\n", size, timer);

	Rss_Open(res, c, size, map, ring_size, nNet);
	//check Mult
	flag = 0;
	for(Lint i =0; i< size; i++)
	{

		res_check[i] = i*i;
		if(!checkbytes(res[i], res_check[i], bytes) && flag == 0)
		{
			printf("Mult ERROR at %d !=   ", i);
			print_1283(res[i]);
			print_1283(res_check[i]);
			flag = 1;
		}
	}
	if(flag == 0){ 
		printf("Mult correct!\n");
	}

	//computation test MultPub:




	gettimeofday(&start,NULL); //start timer here
	Rss_MultPub(res, a, a, size, map, ring_size, nNet); // Mulpub squaring
	gettimeofday(&end,NULL);//stop timer here

	timer = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
	printf("runtime for multpub with data size %d = %ld us\n", size, timer);
	//check MultPub
	flag = 0;
	for(Lint i =0; i< size; i++)
	{


		res_check[i] = i*i;
		// assert(res[i] % Lint(8) == Lint(1));

		// printf("res[i] %u\n", res[i]);

		if(!checkbytes(res[i], res_check[i], bytes) && flag == 0)
		{
			printf("MultPub ERROR at %d !=   ", i);
			print_1283(res[i]);
			print_1283(res_check[i]);
			flag = 1;
		}
		// print_1283(res[i]);
		// print_1283(res_check[i]);
	}
	if(flag == 0)	{
		printf("MultPub correct!\n");
	}
		
	printf("\n");
	printf("Testing RandBit...\n");



	gettimeofday(&start,NULL); //start timer here
	for(int i = 0; i < 10000; i++){
	Rss_RandBit(c, size, map, nNet);
	}
	gettimeofday(&end,NULL);//stop timer here
	for(int i = 0; i< size; i++){
	  d[0][i] = bitExtracted(c[0][i],ring_size);
	  d[1][i] = bitExtracted(c[1][i],ring_size);
	}



	memset(res,0,size*sizeof(Lint));
	Rss_Open(res, d, size, map, ring_size, nNet);

	int count = 0;
	for(int i =0; i< size; i++)
	{
     	  res[i] = bitExtracted(res[i],ring_size);
	  if(res[i] == 1)
	    count++;
	  //printf("res[i] %u\n", res[i]);

	}

	printf("rand 1 is: %u out of %d", count, size);
	timer = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
	printf("runtime for randbit with data size %d = %ld us\n", size, timer);



	//Free memory
	delete [] res;
	// delete [] nres;
	delete [] res_check;
	for(int i = 0; i<3;i++){
		delete [] Data1[i];
		delete [] Data2[i];
	
	}

	delete [] Data1;
	delete [] Data2;
	delete [] a;
	delete [] b;

	delete [] c[0];
	delete [] c[1];
	delete [] c;

        delete [] d[0];                                                                                                                                                                                    
        delete [] d[1];                                                                                                                                                                                    
        delete [] d; 
	/* 
	//*************************************************************************
	//For testing matrix:
	Lint*** ma;
	Lint*** mb;
	Lint*** mc;
	ma = new Lint**[2];
	mb = new Lint**[2];
	mc = new Lint**[2];
	for(int i = 0; i < 2; i++){
		ma[i] = new Lint*[size];
		mb[i] = new Lint*[size];
		mc[i] = new Lint*[size];
		for(int j = 0; j < size; j++){
			ma[i][j] = new Lint[size];
			memset(ma[i][j],0,sizeof(Lint)*size);
			mb[i][j] = new Lint[size];
			memset(mb[i][j],0,sizeof(Lint)*size);
			mc[i][j] = new Lint[size];
			memset(mc[i][j],0,sizeof(Lint)*size);
			for(int k = 0; k < size; k++){
				ma[i][j][k] = 2;
				mb[i][j][k] = 2;
				mc[i][j][k] = 0;
			}
		}
	}

	Lint** result;
	result = new Lint *[size];
	for(int i = 0; i< size; i++){
		result[i] = new Lint [size];
		memset(result[i],0,sizeof(Lint)*size);
	}



	//matrix computation
	gettimeofday(&start,NULL); //start timer here
	Rss_MatMult(mc, ma, mb, size, size, size, map, nNet);
	gettimeofday(&end,NULL);//stop timer here
	timer = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
	printf("runtime for Matrix Mult with data size %d = %ld us\n", size, timer);

	Lint r4= 36*size;
	flag = 0;
	//open and check
	for(int i = 0; i< size; i++){
		Rss_Open_s(result[i], mc[0][i], mc[1][i], size, map, ring_size, nNet);
		for(int j = 0; j< size; j++){
			if(!checkbytes(result[i][j], r4, bytes) && flag == 0){
				printf("MatrixMult ERROR at %d and %d !\n", i,j);
				print_1283(result[i][j]);;
				flag = 1;
			}
		}
	}
	if(flag == 0)	printf("Matrix Mult correct!\n");
	//free memory
	for(int i = 0; i< 2; i++){
		for(int j = 0; j< size; j++){
			delete [] ma[i][j];
			delete [] mb[i][j];
			delete [] mc[i][j];
	
		}
		delete [] ma[i];
		delete [] mb[i];
		delete [] mc[i];
	}
	delete [] ma;
	delete [] mb;
	delete [] mc;

	for(int i = 0; i< size; i++){
		delete [] result[i];
	}
	delete [] result;

	*/
	nNet->prg_clean();
	

}
