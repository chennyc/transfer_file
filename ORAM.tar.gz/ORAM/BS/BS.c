#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <wmmintrin.h>
#include <tmmintrin.h>
#include <gmp.h> 
#include <omp.h>
#include <gcrypt.h>
//#include "Encryption.h"
#include "Network.h"
#include "floram_util.h"
#include "Computation.h"
#include "AESNI_EN.h"
#include "Gen.h"


extern mpz_t d, d_base;
extern uint64_t * k_sys;
extern uint64_t * k1_prg;
extern uint64_t * k2_prg;
extern uint64_t * k3_prg;
extern uint8_t * plaintext_prg_k1;
extern uint8_t * plaintext_prg_k2;
extern uint8_t * plaintext_prg_k3;
extern uint8_t * plaintext_sys;
extern uint8_t * ciphertext_prg; //should be malloc later
extern int ell;

//void aes_encrypt(char *plaintext, int plaintext_len, mpz_t *key, mpz_t *ciper_tmp);
//int find_least_signf(mpz_t op);
//unsigned char testValue1[16];

extern uint8_t * ciphertext_1;
extern uint8_t * ciphertext_2;
extern uint8_t * ciphertext_3;
extern uint8_t * ciphertext_4;

//usage of the en/decrypt function:encrypt (plaintext, strlen ((char *)plaintext), ciphertext);

/*
void Gen_x(mpz_t *x_1, mpz_t *x_2, mpz_t *x_3, int ELE_NUM, )
{
    long long i = 0;
    for(i =0; i<1048576;i++)
    {
        mpz_urandomb (Mem_1[i], state, 128);
        mpz_urandomb (Mem_2[i], state, 128);
        mpz_add (Mem_3[i], Mem_1[i], Mem_2[i]);
        mpz_mod (Mem_3[i], Mem_3[i], d);
        
        mpz_ui_sub (Mem_3[i], ctr, Mem_3[i]);
        mpz_mod (Mem_3[i], Mem_3[i], d);
        
        gmp_fprintf(fw1, "%Zd\n", Mem_1[i]);
        gmp_fprintf(fw2, "%Zd\n", Mem_2[i]);
        gmp_fprintf(fw3, "%Zd\n", Mem_3[i]);
        ctr ++;
        printf("This is %d x %dth data\n", ii, i);
    }
}
*/


int power(int base, int n)
{
    int i, p;
    p = 1;
    for(i = 1; i < n; ++i)
        p = p * base;
    return p;
}

void DotProd(mpz_t * v, mpz_t * Y_a, mpz_t * Y_b, mpz_t t_a, mpz_t t_b, int num)
{
    mpz_t tmp_a;
    mpz_t tmp_b;
    mpz_init(tmp_a);
    mpz_init(tmp_b);
    mpz_set_ui(tmp_a,0);
    mpz_set_ui(tmp_b,0);
    int i;
    for(i=0;i<num;i++)
    {
        mpz_addmul(tmp_a, Y_a[i], t_a[i]);
        mpz_addmul(tmp_b, Y_b[i], t_b[i]);
    }
    mpz_mod (v[0], tmp_a, d);
    mpz_mod (v[1], tmp_b, d);
    
    mpz_clear(tmp_a);
    mpz_clear(tmp_b);
}

void prg_aes_ni_quad(uint64_t * keyed_a, mpz_t alpha_1, mpz_t alpha_2, mpz_t alpha_3, mpz_t alpha_4, uint8_t * plaintext_1, uint8_t * plaintext_2, uint8_t * plaintext_3, uint8_t * plaintext_4)
{
//uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
//	printf("this is prg\n");
	offline_prg(ciphertext_1, plaintext_1, keyed_a);
//	printf("this is prg\n");
	offline_prg(ciphertext_2, plaintext_2, keyed_a);
	offline_prg(ciphertext_3, plaintext_3, keyed_a);
	offline_prg(ciphertext_4, plaintext_4, keyed_a);
//	memcpy(plaintext_prg,ciphertext_prg,16*sizeof(uint8_t));
	mpz_import(alpha_1, 16, 1, sizeof(*ciphertext_1), 0, 0, ciphertext_1);
	mpz_import(alpha_2, 16, 1, sizeof(*ciphertext_2), 0, 0, ciphertext_2);
	mpz_import(alpha_3, 16, 1, sizeof(*ciphertext_3), 0, 0, ciphertext_3);
	mpz_import(alpha_4, 16, 1, sizeof(*ciphertext_4), 0, 0, ciphertext_4);
//	printf("this is prg\n");
	//mpz_mod (alpha, alpha, d);
}

int Eval_gen(int ele_num, mpz_t gamma, mpz_t w_0, mpz_t t_0, mpz_t *sigma, mpz_t **tau, mpz_t *w_T, mpz_t *t_T, int op) 
{
//	printf("this is eval_genn\n");
  struct timeval start;
  struct timeval pause;
  struct timeval end;
  unsigned long timer1;
  unsigned long timer2;
  mpz_t tmp, s_0, s_1, v_0, v_1, read_sum;
  mpz_init(tmp);
  mpz_init(s_0);
  mpz_init(s_1);
  mpz_init(v_0);
  mpz_init(v_1);
  mpz_init(read_sum);
//printf("this is eval_genn\n");
  int i, j, p_last, p_curt, offset, lev_elemt;
  p_last = 0;
  p_curt = 0;
  lev_elemt = 1;
  
  mpz_set(w_T[0],w_0);
  mpz_set(t_T[0],t_0);

//	printf("this is eval_gennn\n");
	//uint8_t * key_prg_w = malloc(16);

	//unsigned char testValue1 = "abcdefghijklmnop";
	uint8_t * plaintext_1 = malloc(16);
	uint8_t * plaintext_2 = malloc(16);
	uint8_t * plaintext_3 = malloc(16);
	uint8_t * plaintext_4 = malloc(16);
	//memset(plaintext_prg_w, 0, 16*sizeof(uint8_t));	

	//memcpy(plaintext_prg_w, testValue1, 16*sizeof(uint8_t));
  //gmp_randstate_t state;
//	printf("this is eval_gen\n");
gettimeofday(&start,NULL);//stop timer here
#pragma omp parallel for num_threads(16)
  for(i=1; i < ELL; i++)
    {
	//long long count=0;
	//count++;

	//if(i==9)printf("this is eval_gen of %d\n", i);
      p_last = p_curt - lev_elemt + 1;     
      for (j=0;j < lev_elemt; j++)
        {
//	printf("i= %d j = %d lev_elment=%d p_curt=%d\n", i, j, lev_elemt,p_curt);
	//count++;
//	printf("this is eval_gen,\n");

          offset = j/2;
	//memcpy(plaintext_prg_w, testValue1, 16*sizeof(uint8_t));
          // s_T[p_curt], v_T[p_curt] <- PRG(w_T[p_last+offset]);
	  //gmp_randinit_mt (state);
	  //gmp_randseed (state, w_T[p_last+offset]);
	mpz_export(plaintext_1, NULL, 1, sizeof(*plaintext_1), 0, 0, w_T[p_last+offset]);
	memcpy(plaintext_2, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_3, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_4, plaintext_1, 16*sizeof(uint8_t));	
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
//printf("this is eval_gen,\n");
	plaintext_2[0] = plaintext_2[0] + 1;
	plaintext_3[0] = plaintext_3[0] + 2;
	plaintext_4[0] = plaintext_4[0] + 3;
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
	//k_sys = offline_prg_keyschedule(key_prg_w);
	prg_aes_ni_quad(k_sys, s_0, s_1, v_0, v_1, plaintext_1, plaintext_2, plaintext_3, plaintext_4);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
//printf("this is eval_gen,\n");
          //mpz_set(tmp,s_T[p_curt][0]);
          mpz_addmul (s_0, t_T[p_last+offset], sigma[i]);
	  mpz_mod (w_T[2*p_curt+1], s_0, d);
	//printf("j= %d, %d and%d\n",j, 2*p_curt+1,2*p_curt+2);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
         // mpz_set(s_1,s_T[p_curt][1]);
          mpz_addmul (s_1, t_T[p_last+offset], sigma[i]);
	//if(i==9)printf("this is eval_gen of %d and %d\n", i, p_curt);
	  mpz_mod (w_T[2*p_curt+2], s_1, d);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
          //mpz_set(tmp,v_T[p_curt][0]);
          mpz_addmul (v_0, t_T[p_last+offset], tau[i][0]);
	  mpz_mod (t_T[2*p_curt+1], v_0, d);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
          //mpz_set(tmp,v_T[p_curt][1]);
          mpz_addmul (v_1, t_T[p_last+offset], tau[i][1]);
	  mpz_mod (t_T[2*p_curt+2], v_1, d);   
          p_curt++;     
        }
	lev_elemt = lev_elemt * 2;
    }

	p_last = p_curt - lev_elemt + 1;
//printf("the first father node is %d\n",p_last);

gettimeofday(&pause,NULL);//stop timer here
timer1 = 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
printf("timer 1= %ld us\n",timer1);


#pragma omp parallel for num_threads(16)
  for(i=0; i < ele_num/2; i++)
    {
	mpz_export(plaintext_1, NULL, 1, sizeof(*plaintext_1), 0, 0, w_T[p_last]);
	memcpy(plaintext_2, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_3, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_4, plaintext_1, 16*sizeof(uint8_t));	
	plaintext_2[0] = plaintext_2[0] + 1;
	plaintext_3[0] = plaintext_3[0] + 2;
	plaintext_4[0] = plaintext_4[0] + 3;
	prg_aes_ni_quad(k_sys, s_0, s_1, v_0, v_1, plaintext_1, plaintext_2, plaintext_3, plaintext_4);

	if(op == 0)// op=1 means this operation is read
	{
          //mpz_set(tmp,s_0);
          mpz_addmul (s_0, t_T[p_last], sigma[ELL]); //ELL here maybe wrong
	  mpz_mod (s_0, s_0, d); //s_0 = w^ll of left(0) child

          //mpz_set(tmp,s_T[p_curt][1]);
          mpz_addmul (s_1, t_T[p_last], sigma[ELL]);
	  mpz_mod (s_1, s_1, d);//s_1 = w^ll of right(1) child
	}
          //mpz_set(v_0,v_T[p_curt][0]);
          mpz_addmul (v_0, t_T[p_last], tau[ELL][0]);
	  mpz_mod (v_0, v_0, d);//v_0 = t^ll of left(0) child

          //mpz_set(tmp,v_T[p_curt][1]);
          mpz_addmul (v_1, t_T[p_last], tau[ELL][1]);
	  mpz_mod (v_1, v_1, d); //v_1 = t^ll of right(1) child
	if(op == 0)// op=1 means this operation is read
	{
	//mpz_set(tmp,s_0);//srore the 
        mpz_addmul (s_0, v_0, gamma); //s_0 = y_T
        mpz_addmul (s_1, v_1, gamma); 
	//write the y_T into memory.
	}
	else
	{
	        mpz_addmul (read_sum, read_sum, v_0); 
	        mpz_addmul (read_sum, read_sum, v_1); 
	}
    }
		//output the read_sum if needed.
  mpz_clear(tmp);
  mpz_clear(s_0);
  mpz_clear(s_1);
  mpz_clear(v_0);
  mpz_clear(v_1);
  mpz_clear(read_sum);
  //free(key_prg_w );
  //free(plaintext_prg_w);
	printf("this is eval_genn\n");

gettimeofday(&end,NULL);//stop timer here
timer2 = 1000000 * (end.tv_sec-pause.tv_sec)+ end.tv_usec-pause.tv_usec;
printf("timer 2= %ld us\n",timer2);
  return 0;

}

void BS_three(mpz_t* sigma_list, mpz_t gamma, mpz_t* tau0_list, mpz_t* tau1_list, mpz_t* fk_1, mpz_t* fk_2, mpz_t* fk_3, mpz_t beta_1, mpz_t beta_2, mpz_t beta_3, mpz_t* alpha1, mpz_t* alpha2, mpz_t* alpha3, int *neighfd, struct memberlist *p, 	struct memberlist *mp, uint64_t * k1_prg, uint64_t * k2_prg, uint64_t * k3_prg, uint64_t * k_sys, struct message *msgp, struct aesmessage *aesmsgp, __m128i *key_aesen)
{
	int j, i;
	struct timeval start;
	struct timeval pause;
	struct timeval end;

	unsigned long timer1;


        mpz_t w0_3, w0_1, w0_2;
	mpz_init (w0_3);
	mpz_init (w0_1);
	mpz_init (w0_2);


        mpz_t t0_3, t0_1, t0_2;
	mpz_init (t0_3);
	mpz_init (t0_1);
	mpz_init (t0_2);


	mpz_init_set_ui (t0_3, 0); //t0_1 = t for party 2
	mpz_init_set_ui (t0_1, 1);
	mpz_init_set_ui (t0_2, 0);
	//mpz_urandomm (w0_3, state, d); 
	//mpz_urandomm (w0_3, state, d);
	//mpz_urandomm (w0_1, state, d);//RandF()

	mpz_set(fk_3[0], w0_3);
	mpz_set(fk_2[0], w0_2);
	mpz_set(fk_1[0], w0_1);
	mpz_set(fk_3[1], t0_3);
	mpz_set(fk_2[1], t0_2);
	mpz_set(fk_1[1], t0_1);


        mpz_t sj0_3, sj0_1, sj0_2;
        mpz_t sj1_3, sj1_1, sj1_2;
	mpz_init (sj0_3);
	mpz_init (sj0_1);
	mpz_init (sj0_2);
	mpz_init (sj1_3);
	mpz_init (sj1_1);
	mpz_init (sj1_2);

        mpz_t sjal_3, sjal_1, sjal_2; //s^j_alpha
        mpz_t sjhal_3, sjhal_1,  sjhal_2;
	mpz_init (sjal_3);
	mpz_init (sjal_1);
	mpz_init (sjal_2);
	mpz_init (sjhal_3);
	mpz_init (sjhal_1);
	mpz_init (sjhal_2);

        mpz_t vj0_3, vj0_1, vj0_2;
        mpz_t vj1_3, vj1_1, vj1_2;
	mpz_init (vj0_3);
	mpz_init (vj0_1);
	mpz_init (vj0_2);
	mpz_init (vj1_3);
	mpz_init (vj1_1);
	mpz_init (vj1_2);

        mpz_t vjal_3, vjal_1, vjal_2; //v^j_alpha
	mpz_init (vjal_3);
	mpz_init (vjal_1);
	mpz_init (vjal_2);
	
        mpz_t tauj0_3, tauj0_1, tauj0_2;
        mpz_t tauj1_3, tauj1_1, tauj1_2;
	mpz_init (tauj0_3);
	mpz_init (tauj0_1);
	mpz_init (tauj0_2);
	mpz_init (tauj1_3);
	mpz_init (tauj1_1);
	mpz_init (tauj1_2);


        mpz_t tau0, tau1; //tau^j_0,1
	mpz_init (tau0);
	mpz_init (tau1);

        mpz_t taujal_3, taujal_1, taujal_2; //tau^j_alpha
	mpz_init (taujal_3);
	mpz_init (taujal_1);
	mpz_init (taujal_2);

        mpz_t u_3, u_1, u_2; //u
	mpz_init (u_3);
	mpz_init (u_1);
	mpz_init (u_2);

        mpz_t sigma;
	mpz_init (sigma);

    mpz_t* s = Init_one (3);
        mpz_set_ui(s[0], 0); // 0+1+2=3, so 3 is the expected key value
        mpz_set_ui(s[1], 1);
        mpz_set_ui(s[2], 2);
	//gmp_randstate_t prg_state;
    int N_p;
    
    mpz_t* Y_a = Init_one(ELE_NUM);
    mpz_t* Y_b = Init_one(ELE_NUM); //need clear

    mpz_t* alpha_tmp = Init_one (2);
    mpz_t* s_tmp = Init_one (2);
    mpz_t* X_tmp = Init_one (2);            
    int index_tmp;
  switch(p->party_no)
    {
    case 1://this is a=1
	printf("this is a--\n");
	setconnect_a(mp,msgp,neighfd);

	gettimeofday(&start,NULL); //start timer here
	prg_aes_ni(k2_prg, w0_2, plaintext_prg_k2);
	prg_aes_ni(k3_prg, w0_3, plaintext_prg_k3);


    
    mpz_set (s_tmp[0], s[1]); // s[1] is the s_2
    mpz_set (s_tmp[1], s[2]);// s[2] is the s_3


            index_tmp = power(2, ell -1)
    mpz_set (X_tmp[0], x_2[index_tmp]); //
    mpz_set (X_tmp[1], x_3[index_tmp]);//
    
            mpz_sub(X_tmp[0], s_tmp[0],X_tmp[0]);
            mpz_sub(X_tmp[1], s_tmp[1],X_tmp[1]);
            LTZ(alpha_tmp, X_tmp, ); // TODO
            mpz_set(alpha2[0], alpha_tmp[0]);
            mpz_set(alpha3[0], alpha_tmp[1]);
	for(j=0;j<ell;j++)
	{
		

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_2);//prg wj-1_[2]
		//set [w^{j-1}] as the key
/*
		mpz_export(key_prg_w2, NULL, 1, sizeof(*key_prg_w2), 0, 0, w0_2);
		mpz_export(key_prg_w3, NULL, 1, sizeof(*key_prg_w3), 0, 0, w0_3);
		keyed_prg_w2 = offline_prg_keyschedule(key_prg_w2);
		keyed_prg_w3 = offline_prg_keyschedule(key_prg_w3);

		prg_aes_ni(keyed_prg_w2, sj0_2, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w2, vj0_2, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w2, sj1_2, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w2, vj1_2, plaintext_prg_wa);

		prg_aes_ni(keyed_prg_w3, sj0_3, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w3, vj0_3, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w3, sj1_3, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w3, vj1_3, plaintext_prg_wb);
*/
		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_2);
		prg_aes_ni(k_sys, sj0_2, plaintext_sys);
		prg_aes_ni(k_sys, vj0_2, plaintext_sys);
		prg_aes_ni(k_sys, sj1_2, plaintext_sys);
		prg_aes_ni(k_sys, vj1_2, plaintext_sys);

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_3);
		prg_aes_ni(k_sys, sj0_3, plaintext_sys);
		prg_aes_ni(k_sys, vj0_3, plaintext_sys);
		prg_aes_ni(k_sys, sj1_3, plaintext_sys);
		prg_aes_ni(k_sys, vj1_3, plaintext_sys);
		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_3);//prg wj-1_[3]

		//mpz_urandomm (sj0_3, prg_state, d); 
		//mpz_urandomm (vj0_3, prg_state, d); 
		//mpz_urandomm (sj1_3, prg_state, d); 
		//mpz_urandomm (vj1_3, prg_state, d); 

		mpz_sub (u_2, sj1_2, sj0_2);
		mpz_mod (u_2, u_2, d);

		mpz_sub (u_3, sj1_3, sj0_3);
		mpz_mod (u_3, u_3, d);

		//threemultip(neighfd, alpha2[j], alpha3[j], sj1_2, sj1_3, u_2, u_3);
		threemultip(neighfd, u_2, u_3, alpha2[j], alpha3[j], u_2, u_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen);
		mpz_add (sjal_2, u_2, sj0_2);
		mpz_mod (sjal_2, sjal_2, d);
		mpz_add (sjal_3, u_3, sj0_3);
		mpz_mod (sjal_3, sjal_3, d);

		mpz_sub (sjhal_2, sj1_2, u_2);
		mpz_mod (sjhal_2, sjhal_2, d);
		mpz_sub (sjhal_3, sj1_3, u_3);
		mpz_mod (sjhal_3, sjhal_3, d);

		//sigma = threeopen(neighfd, sjhal_2, sjhal_3, msgp); //Open([s^{j,minus\alpha_j}])
		//gettimeofday(&open_start,NULL); //start timer here
		threeopen(neighfd, sjhal_2, sjhal_3, sigma, aesmsgp, key_aesen);
		//gettimeofday(&open_end,NULL); //start timer here
		//timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;

		mpz_add (u_2, vj0_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add_ui (u_2, u_2, 0); //1_2 = 1_3 =0, 1_1 =1
		mpz_mod (u_2, u_2, d);
		mpz_add (u_3, vj0_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		mpz_add_ui (u_3, u_3, 0);
		mpz_mod (u_3, u_3, d);
		
		//gettimeofday(&open_start,NULL); //start timer here
		threeopen(neighfd, u_2, u_3, tau0 , aesmsgp, key_aesen); //tau^{j,0}
		//gettimeofday(&open_end,NULL); //start timer here
		//timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;

		mpz_add (u_2, vj1_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add (u_3, vj1_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		
		//gettimeofday(&open_start,NULL); //start timer here
		threeopen(neighfd, u_2, u_3, tau1, aesmsgp, key_aesen); //tau^{j,0}
		//gettimeofday(&open_end,NULL); //start timer here
		//timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;

		mpz_mul (u_2, t0_2, sigma); 
		mpz_mod (u_2, u_2, d);
		mpz_mul (u_3, t0_3, sigma);
		mpz_mod (u_3, u_3, d);

		mpz_add (w0_2, sjal_2, u_2);
		mpz_mod (w0_2, w0_2, d);
		mpz_add (w0_3, sjal_3, u_3);
		mpz_mod (w0_3, w0_3, d);		//[w^j]= ...


		mpz_sub (u_2, tau1, tau0);
		mpz_mod (u_2, u_2, d);
		//mpz_sub (u_2, vj1_2, vj0_2);
		//mpz_mod (u_2, u_2, d);
		mpz_mul (taujal_2, u_2, alpha2[j]);
		mpz_mod (taujal_2, taujal_2, d);	
		mpz_mul (taujal_3, u_2, alpha3[j]);
		mpz_mod (taujal_3, taujal_3, d);

		mpz_add (taujal_2, taujal_2, tau0); //tau0_1 =tau0, and _2 =0
		mpz_mod (taujal_2, taujal_2, d);
		mpz_add_ui (taujal_3, taujal_3, 0);
		mpz_mod (taujal_3, taujal_3, d);
		threemultip(neighfd, u_2, u_3, t0_2, t0_3, taujal_2, taujal_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen); //u_1 = t^(j-1)_1 \times tau^{j,\alpha_j}_1
	

		mpz_sub (vjal_2, vj1_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		mpz_sub (vjal_3, vj1_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);
		threemultip(neighfd, vjal_2, vjal_3, alpha2[j], alpha3[j], vjal_2, vjal_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen);

		mpz_add (vjal_2,  vjal_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		mpz_add (vjal_3,  vjal_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);


		mpz_add (t0_2,  vjal_2, u_2);
		mpz_mod (t0_2, t0_2, d);
		mpz_add (t0_3,  vjal_3, u_3);
		mpz_mod (t0_3, t0_3, d);
		
		mpz_set (sigma_list[j], sigma);
		mpz_set (tau0_list[j], tau0);
		mpz_set (tau1_list[j], tau1);
        
        if(j+1<ell)
        {
            index_tmp = power(2, ell-j-1);
            N_p = (ELE_NUM + index_tmp/2)/2;
            Eval();//TODO

            
            for (i =0; i< N_p; i++)
            {
                index_tmp = power(2, ell - j - 2);
                index_tmp =(2i+1)*index_tmp;
                mpz_set(Y_a[j], x_2[index_tmp]);
                mpz_set(Y_b[j], x_3[index_tmp]);
            }
            DotProd(X_tmp, Y_a, Y_b, t_a, t_b, N_p);
            mpz_sub(X_tmp[0], s_tmp[0],X_tmp[0]);
            mpz_sub(X_tmp[1], s_tmp[1],X_tmp[1]);
            LTZ(alpha_tmp, X_tmp, ); // TODO
            mpz_set(alpha2[0], alpha_tmp[0]);
            mpz_set(alpha3[0], alpha_tmp[1]);
        }
	}
//	mpz_add (u_2, w0_2, beta_2);
//	mpz_mod (u_2, u_2, d);
//	mpz_add (u_3, w0_3, beta_3);
//	mpz_mod (u_3, u_3, d);
	
//	gettimeofday(&open_start,NULL); //start timer here
//	threeopen(neighfd, u_2, u_3, gamma, aesmsgp, key_aesen); //open \gama
//	gettimeofday(&open_end,NULL); //start timer here
//	timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
//	printf("timer open= %ld us\n",timer_open);
/*
	gmp_printf ("fk_2: %Zd,\n %Zd \n",fk_2[0], fk_2[1]);
	gmp_printf ("fk_3: %Zd,\n %Zd \n", fk_3[0], fk_3[1]);
	for(j=0;j<ell;j++)
	{
		gmp_printf ("sigma %d: %Zd \n sigma %d: %Zd \n sigma %d: %Zd \n", j, sigma_list[j], j, tau0_list[j], j, tau1_list[j]);
	}
      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
*/
      break;

    case 2://this is b=3
	printf("this is b--\n");
	setconnect_b(mp,msgp,neighfd);
	gettimeofday(&start,NULL); //start timer here
	prg_aes_ni(k1_prg, w0_1, plaintext_prg_k1);
	prg_aes_ni(k2_prg, w0_2, plaintext_prg_k2);

   
    mpz_set (s_tmp[0], s[0]); // s[0] is the s_1
    mpz_set (s_tmp[1], s[1]);// s[1] is the s_2


            index_tmp = power(2, ell -1)
    mpz_set (X_tmp[0], x_1[index_tmp]); //
    mpz_set (X_tmp[1], x_2[index_tmp]);//
    
            mpz_sub(X_tmp[0], s_tmp[0],X_tmp[0]);
            mpz_sub(X_tmp[1], s_tmp[1],X_tmp[1]);
            LTZ(alpha_tmp, X_tmp, ); // TODO
            mpz_set(alpha1[0], alpha_tmp[0]);
            mpz_set(alpha2[0], alpha_tmp[1]);
	for(j=0;j<ell;j++)
	{
		

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_1);//prg wj-1_[2]
		//set [w^{j-1}] as the key
/*		mpz_export(key_prg_w1, NULL, 1, sizeof(*key_prg_w1), 0, 0, w0_1);
		mpz_export(key_prg_w2, NULL, 1, sizeof(*key_prg_w2), 0, 0, w0_2);
		keyed_prg_w1 = offline_prg_keyschedule(key_prg_w2);
		keyed_prg_w2 = offline_prg_keyschedule(key_prg_w3);

		prg_aes_ni(keyed_prg_w1, sj0_1, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w1, vj0_1, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w1, sj1_1, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w1, vj1_1, plaintext_prg_wa);

		prg_aes_ni(keyed_prg_w2, sj0_2, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w2, vj0_2, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w2, sj1_2, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w2, vj1_2, plaintext_prg_wb);
*/

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_1);
		prg_aes_ni(k_sys, sj0_1, plaintext_sys);
		prg_aes_ni(k_sys, vj0_1, plaintext_sys);
		prg_aes_ni(k_sys, sj1_1, plaintext_sys);
		prg_aes_ni(k_sys, vj1_1, plaintext_sys);

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_2);
		prg_aes_ni(k_sys, sj0_2, plaintext_sys);
		prg_aes_ni(k_sys, vj0_2, plaintext_sys);
		prg_aes_ni(k_sys, sj1_2, plaintext_sys);
		prg_aes_ni(k_sys, vj1_2, plaintext_sys);

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_2);//prg wj-1_[3]

		//mpz_urandomm (sj0_2, prg_state, d); 
		//mpz_urandomm (vj0_2, prg_state, d); 
		//mpz_urandomm (sj1_2, prg_state, d); 
		//mpz_urandomm (vj1_2, prg_state, d); 

		mpz_sub (u_1, sj1_1, sj0_1);
		mpz_mod (u_1, u_1, d);

		mpz_sub (u_2, sj1_2, sj0_2);
		mpz_mod (u_2, u_2, d);

		//threemultip(neighfd, alpha2[j], alpha3[j], sj1_1, sj1_2, u_1, u_2);
		threemultip(neighfd, u_1, u_2, alpha1[j], alpha2[j], u_1, u_2, k1_prg, k2_prg, 1,plaintext_prg_k1, plaintext_prg_k2, aesmsgp, key_aesen);
		mpz_add (sjal_1, u_1, sj0_1);
		mpz_mod (sjal_1, sjal_1, d);
		mpz_add (sjal_2, u_2, sj0_2);
		mpz_mod (sjal_2, sjal_2, d);

		mpz_sub (sjhal_1, sj1_1, u_1);
		mpz_mod (sjhal_1, sjhal_1, d);
		mpz_sub (sjhal_2, sj1_2, u_2);
		mpz_mod (sjhal_2, sjhal_2, d);

		//sigma = threeopen(neighfd, sjhal_1, sjhal_2, msgp); //Open([s^{j,minus\alpha_j}])
		threeopen(neighfd, sjhal_1, sjhal_2, sigma, aesmsgp, key_aesen);

		mpz_add (u_1, vj0_1, alpha1[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add_ui (u_1, u_1, 1); //1_1 =1, 1_2 =0
		mpz_mod (u_1, u_1, d);
		mpz_add (u_2, vj0_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add_ui (u_2, u_2, 0);
		mpz_mod (u_2, u_2, d);
		
		threeopen(neighfd, u_1, u_2, tau0 , aesmsgp, key_aesen); //tau^{j,0}

		mpz_add (u_1, vj1_1, alpha1[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add (u_2, vj1_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		
		threeopen(neighfd, u_1, u_2, tau1, aesmsgp, key_aesen); //tau^{j,0}

		mpz_mul (u_1, t0_1, sigma); 
		mpz_mod (u_1, u_1, d);
		mpz_mul (u_2, t0_2, sigma);
		mpz_mod (u_2, u_2, d);

		mpz_add (w0_1, sjal_1, u_1);
		mpz_mod (w0_1, w0_1, d);
		mpz_add (w0_2, sjal_2, u_2);
		mpz_mod (w0_2, w0_2, d);		//[w^j]= ...


		mpz_sub (u_1, tau1, tau0);
		mpz_mod (u_1, u_1, d);
		//mpz_sub (u_2, vj1_2, vj0_2);
		//mpz_mod (u_2, u_2, d);
		mpz_mul (taujal_1, u_1, alpha1[j]);
		mpz_mod (taujal_1, taujal_1, d);	
		mpz_mul (taujal_2, u_1, alpha2[j]);
		mpz_mod (taujal_2, taujal_2, d);

		mpz_add (taujal_1, taujal_1, tau0); //tau0_1 =tau0, and _2 =0
		mpz_mod (taujal_1, taujal_1, d);
		mpz_add_ui (taujal_2, taujal_2, 0);
		mpz_mod (taujal_2, taujal_2, d);
		threemultip(neighfd, u_1, u_2, t0_1, t0_2, taujal_1, taujal_2, k1_prg, k2_prg, 1,plaintext_prg_k1, plaintext_prg_k2, aesmsgp, key_aesen); //u_1 = t^(j-1)_1 \times tau^{j,\alpha_j}_1
	

		mpz_sub (vjal_1, vj1_1, vj0_1);
		mpz_mod (vjal_1, vjal_1, d);
		mpz_sub (vjal_2, vj1_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		threemultip(neighfd, vjal_1, vjal_2, alpha1[j], alpha2[j], vjal_1, vjal_2, k1_prg, k2_prg, 1,plaintext_prg_k1, plaintext_prg_k2, aesmsgp, key_aesen);

		mpz_add (vjal_1,  vjal_1, vj0_1);
		mpz_mod (vjal_1, vjal_1, d);
		mpz_add (vjal_2,  vjal_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);


		mpz_add (t0_1,  vjal_1, u_1);
		mpz_mod (t0_1, t0_1, d);
		mpz_add (t0_2,  vjal_2, u_2);
		mpz_mod (t0_2, t0_2, d);
		
		mpz_set (sigma_list[j], sigma);
		mpz_set (tau0_list[j], tau0);
		mpz_set (tau1_list[j], tau1);

        if(j+1<ell)
        {
            index_tmp = power(2, ell-j-1);
            N_p = (ELE_NUM + index_tmp/2)/2;
            Eval();//TODO

            
            for (i =0; i< N_p; i++)
            {
                index_tmp = power(2, ell - j - 2);
                index_tmp =(2i+1)*index_tmp;
                mpz_set(Y_a[j], x_1[index_tmp]);
                mpz_set(Y_b[j], x_2[index_tmp]);
            }
            DotProd(X_tmp, Y_a, Y_b, t_a, t_b, N_p);
            mpz_sub(X_tmp[0], s_tmp[0],X_tmp[0]);
            mpz_sub(X_tmp[1], s_tmp[1],X_tmp[1]);
            LTZ(alpha_tmp, X_tmp, ); // TODO
            mpz_set(alpha1[0], alpha_tmp[0]);
            mpz_set(alpha2[0], alpha_tmp[1]);
        }


	}
/*
	gmp_printf ("fk_1: %Zd,\n %Zd \n",fk_1[0], fk_1[1]);
	gmp_printf ("fk_2: %Zd,\n %Zd \n", fk_2[0], fk_2[1]);
	for(j=0;j<ell;j++)
	{
		gmp_printf ("sigma %d: %Zd \n sigma %d: %Zd \n sigma %d: %Zd \n", j, sigma_list[j], j, tau0_list[j], j, tau1_list[j]);
	}
      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
*/
      break;

    case 3://this is c=2
	printf("this is c--\n");
	setconnect_c(mp,msgp,neighfd);

	gettimeofday(&start,NULL); //start timer here
	prg_aes_ni(k3_prg, w0_3, plaintext_prg_k3);
	prg_aes_ni(k1_prg, w0_1, plaintext_prg_k1);

   
    mpz_set (s_tmp[0], s[2]); // s[2] is the s_3
    mpz_set (s_tmp[1], s[0]);// s[0] is the s_1


            index_tmp = power(2, ell -1)
    mpz_set (X_tmp[0], x_3[index_tmp]); //
    mpz_set (X_tmp[1], x_1[index_tmp]);//
    
            mpz_sub(X_tmp[0], s_tmp[0],X_tmp[0]);
            mpz_sub(X_tmp[1], s_tmp[1],X_tmp[1]);
            LTZ(alpha_tmp, X_tmp, ); // TODO
            mpz_set(alpha3[0], alpha_tmp[0]);
            mpz_set(alpha1[0], alpha_tmp[1]);

	for(j=0;j<ell;j++)
	{
		

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_3);//prg wj-1_[2]
		//set [w^{j-1}] as the key
/*		mpz_export(key_prg_w3, NULL, 1, sizeof(*key_prg_w3), 0, 0, w0_3);
		mpz_export(key_prg_w1, NULL, 1, sizeof(*key_prg_w1), 0, 0, w0_1);
		keyed_prg_w3 = offline_prg_keyschedule(key_prg_w3);
		keyed_prg_w1 = offline_prg_keyschedule(key_prg_w1);

		prg_aes_ni(keyed_prg_w3, sj0_3, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w3, vj0_3, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w3, sj1_3, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w3, vj1_3, plaintext_prg_wa);

		prg_aes_ni(keyed_prg_w1, sj0_1, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w1, vj0_1, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w1, sj1_1, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w1, vj1_1, plaintext_prg_wb);
*/

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_3);
		prg_aes_ni(k_sys, sj0_3, plaintext_sys);
		prg_aes_ni(k_sys, vj0_3, plaintext_sys);
		prg_aes_ni(k_sys, sj1_3, plaintext_sys);
		prg_aes_ni(k_sys, vj1_3, plaintext_sys);

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_1);
		prg_aes_ni(k_sys, sj0_1, plaintext_sys);
		prg_aes_ni(k_sys, vj0_1, plaintext_sys);
		prg_aes_ni(k_sys, sj1_1, plaintext_sys);
		prg_aes_ni(k_sys, vj1_1, plaintext_sys);
		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_1);//prg wj-1_[3]

		//mpz_urandomm (sj0_1, prg_state, d); 
		//mpz_urandomm (vj0_1, prg_state, d); 
		//mpz_urandomm (sj1_1, prg_state, d); 
		//mpz_urandomm (vj1_1, prg_state, d); 

		mpz_sub (u_3, sj1_3, sj0_3);
		mpz_mod (u_3, u_3, d);

		mpz_sub (u_1, sj1_1, sj0_1);
		mpz_mod (u_1, u_1, d);

		//threemultip(neighfd, alpha2[j], alpha3[j], sj1_3, sj1_1, u_3, u_1);
		threemultip(neighfd, u_3, u_1, alpha3[j], alpha1[j], u_3, u_1, k3_prg, k1_prg, 1,plaintext_prg_k3, plaintext_prg_k1, aesmsgp, key_aesen);
		mpz_add (sjal_3, u_3, sj0_3);
		mpz_mod (sjal_3, sjal_3, d);
		mpz_add (sjal_1, u_1, sj0_1);
		mpz_mod (sjal_1, sjal_1, d);

		mpz_sub (sjhal_3, sj1_3, u_3);
		mpz_mod (sjhal_3, sjhal_3, d);
		mpz_sub (sjhal_1, sj1_1, u_1);
		mpz_mod (sjhal_1, sjhal_1, d);

		//sigma = threeopen(neighfd, sjhal_3, sjhal_1, msgp); //Open([s^{j,minus\alpha_j}])
		threeopen(neighfd, sjhal_3, sjhal_1, sigma, aesmsgp, key_aesen);

		mpz_add (u_3, vj0_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		mpz_add_ui (u_3, u_3, 0); //1_1 =0, 1_3 =0
		mpz_mod (u_3, u_3, d);
		mpz_add (u_1, vj0_1, alpha1[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add_ui (u_1, u_1, 1);
		mpz_mod (u_1, u_1, d);
		
		threeopen(neighfd, u_3, u_1, tau0 , aesmsgp, key_aesen); //tau^{j,0}

		mpz_add (u_3, vj1_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		mpz_add (u_1, vj1_1, alpha1[j]);
		mpz_mod (u_1, u_1, d);
		
		threeopen(neighfd, u_3, u_1, tau1, aesmsgp, key_aesen); //tau^{j,0}

		mpz_mul (u_3, t0_3, sigma); 
		mpz_mod (u_3, u_3, d);
		mpz_mul (u_1, t0_1, sigma);
		mpz_mod (u_1, u_1, d);

		mpz_add (w0_3, sjal_3, u_3);
		mpz_mod (w0_3, w0_3, d);
		mpz_add (w0_1, sjal_1, u_1);
		mpz_mod (w0_1, w0_1, d);		//[w^j]= ...


		mpz_sub (u_3, tau1, tau0);
		mpz_mod (u_3, u_3, d);
		//mpz_sub (u_1, vj1_1, vj0_1);
		//mpz_mod (u_1, u_1, d);
		mpz_mul (taujal_3, u_3, alpha3[j]);
		mpz_mod (taujal_3, taujal_3, d);	
		mpz_mul (taujal_1, u_3, alpha1[j]);
		mpz_mod (taujal_1, taujal_1, d);

		mpz_add_ui (taujal_3, taujal_3, 0); //tau0_1 =tau0, and _1 =0
		mpz_mod (taujal_3, taujal_3, d);
		mpz_add (taujal_1, taujal_1, tau0);
		mpz_mod (taujal_1, taujal_1, d);
		threemultip(neighfd, u_3, u_1, t0_3, t0_1, taujal_3, taujal_1, k3_prg, k1_prg, 1,plaintext_prg_k3, plaintext_prg_k1, aesmsgp, key_aesen); //u_3 = t^(j-1)_3 \times tau^{j,\alpha_j}_3
	

		mpz_sub (vjal_3, vj1_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);
		mpz_sub (vjal_1, vj1_1, vj0_1);
		mpz_mod (vjal_1, vjal_1, d);
		threemultip(neighfd, vjal_3, vjal_1, alpha3[j], alpha1[j], vjal_3, vjal_1, k3_prg, k1_prg, 1,plaintext_prg_k3, plaintext_prg_k1, aesmsgp, key_aesen);

		mpz_add (vjal_3,  vjal_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);
		mpz_add (vjal_1,  vjal_1, vj0_1);
		mpz_mod (vjal_1, vjal_1, d);


		mpz_add (t0_3,  vjal_3, u_3);
		mpz_mod (t0_3, t0_3, d);
		mpz_add (t0_1,  vjal_1, u_1);
		mpz_mod (t0_1, t0_1, d);
		
		mpz_set (sigma_list[j], sigma);
		mpz_set (tau0_list[j], tau0);
		mpz_set (tau1_list[j], tau1);


        if(j+1<ell)
        {
            index_tmp = power(2, ell-j-1);
            N_p = (ELE_NUM + index_tmp/2)/2;
            Eval();//TODO

            
            for (i =0; i< N_p; i++)
            {
                index_tmp = power(2, ell - j - 2);
                index_tmp =(2i+1)*index_tmp;
                mpz_set(Y_a[j], x_3[index_tmp]);
                mpz_set(Y_b[j], x_1[index_tmp]);
            }
            DotProd(X_tmp, Y_a, Y_b, t_a, t_b, N_p);
            mpz_sub(X_tmp[0], s_tmp[0],X_tmp[0]);
            mpz_sub(X_tmp[1], s_tmp[1],X_tmp[1]);
            LTZ(alpha_tmp, X_tmp, ); // TODO
            mpz_set(alpha3[0], alpha_tmp[0]);
            mpz_set(alpha1[0], alpha_tmp[1]);
        }
	}

/*
	gmp_printf ("fk_3: %Zd,\n %Zd \n",fk_3[0], fk_3[1]);
	gmp_printf ("fk_1: %Zd,\n %Zd \n", fk_1[0], fk_1[1]);
	for(j=0;j<ell;j++)
	{
		gmp_printf ("sigma %d: %Zd \n tau0 %d: %Zd \n tau1 %d: %Zd \n", j, sigma_list[j], j, tau0_list[j], j, tau1_list[j]);
	}
      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
*/
	//printf("this is ok--\n");
      break;

    }
	//printf("this is ok--\n");


	//printf("this is ok--\n");

	//printf("this is ok--\n");



	//printf("this is ok--\n");
	mpz_clear(w0_1);
	mpz_clear(w0_2);
	mpz_clear(w0_3);
	mpz_clear(t0_1);
	mpz_clear(t0_2);
	mpz_clear(t0_3);



	mpz_clear(sj0_1);
	mpz_clear(sj0_2);
	mpz_clear(sj0_3);
	mpz_clear(sj1_1);
	mpz_clear(sj1_2);
	mpz_clear(sj1_3);
	mpz_clear(sjal_1);
	//printf("this is ok--\n");
	mpz_clear(sjal_2);
	mpz_clear(sjal_3);
	mpz_clear(sjhal_1);
	mpz_clear(sjhal_2);
	mpz_clear(sjhal_3);
	mpz_clear(vj0_1);
	mpz_clear(vj0_2);
	mpz_clear(vj0_3);
	mpz_clear(vj1_1);
	mpz_clear(vj1_2);
	mpz_clear(vj1_3);
	mpz_clear(vjal_1);
	mpz_clear(vjal_2);
	mpz_clear(vjal_3);
	mpz_clear(tauj0_1);
	mpz_clear(tauj0_2);
	mpz_clear(tauj0_3);
	mpz_clear(tauj1_1);
	mpz_clear(tauj1_2);
	mpz_clear(tauj1_3);
	mpz_clear(tau0);
	//printf("this is ok--\n");
	mpz_clear(tau1);
	mpz_clear(taujal_1);
	mpz_clear(taujal_2);
	mpz_clear(taujal_3);
	mpz_clear(u_1);
	mpz_clear(u_2);
	mpz_clear(u_3);
	mpz_clear(sigma);
	//printf("this is ok--\n");

        mpz_clear(s[0], 0);
        mpz_clear(s[1], 0);
        mpz_clear(s[2], 0);

    mpz_t_clear(alpha_tmp[0]);
    mpz_t_clear(alpha_tmp[1]);
    mpz_t_clear(s_tmp[0]);
    mpz_t_clear(s_tmp[1]);
    mpz_t_clear(X_tmp[0]);
    mpz_t_clear(X_tmp[1]);

	gettimeofday(&pause,NULL);//stop timer here
	timer1 = 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
	printf("timer 1= %ld us\n",timer1);
	for(i=0;i<ELE_NUM;i++)
	{
		mpz_clear(Y_a[i]);
		mpz_clear(Y_b[i]);
	}
}

