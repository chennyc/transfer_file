#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <gmp.h>
#include <stdint.h>  


extern mpz_t d, d_base;


//SS_ModMul
void SS_modMul_basic(mpz_t result, mpz_t x, mpz_t y){
	mpz_mul(result,x,y);
	mpz_mod(result,result,d);

}

 void SS_modMul_allarray(mpz_t* result, mpz_t* x, mpz_t* y, int size){
	for(int i = 0; i < size; i++)
		SS_modMul_basic(result[i],x[i],y[i]);
}

void SS_modMul_halfarray(mpz_t* result, mpz_t* x, mpz_t y, int size){
	for(int i=0; i<size; ++i){
		SS_modMul_basic(result[i],x[i],y);
	}
}

void SS_modMul_L(mpz_t result, mpz_t x, long y){
	mpz_mul_si(result,x,y);
	mpz_mod(result,result,d);
}

void SS_modMul_L_array(mpz_t* result, mpz_t* x, long y, int size){
	for(int i=0; i<size; ++i){
		SS_modMul_L(result[i],x[i],y);
	}
}

//SS_ModAdd
void SS_modAdd_basic(mpz_t result, mpz_t x, mpz_t y){
	mpz_add(result,x,y);
	mpz_mod(result,result,d);
}

void SS_modAdd_allarray(mpz_t* result, mpz_t* x, mpz_t* y, int size){
	for(int i = 0; i < size; i++)
		SS_modAdd_basic(result[i],x[i],y[i]);
}

void SS_modAdd_L(mpz_t result, mpz_t x, long y){
	mpz_t y1;
	mpz_init_set_si(y1, y);
	mpz_add(result, x, y1);
	mpz_mod(result, result, d);
	mpz_clear(y1); 
}

void SS_modAdd_L_array(mpz_t* result, mpz_t*x, long y, int size){
	for(int i=0; i<size; ++i)
		SS_modAdd_L(result[i], x[i], y);
}

void SS_modAdd_halfarray(mpz_t* result, mpz_t* x, mpz_t y, int size){
	for(int i = 0; i < size; i++)
		SS_modAdd_basic(result[i], x[i], y); 
}
//SS_ModSub
void SS_modSub_basic(mpz_t result, mpz_t x, mpz_t y){
	mpz_sub(result,x,y);
	mpz_mod(result,result,d);
}

void SS_modSub_allarray(mpz_t* result, mpz_t* x, mpz_t* y, int size){
	for(int i = 0; i < size; i++)
		SS_modSub_basic(result[i],x[i],y[i]);
}


void SS_modSub_L_y(mpz_t result, mpz_t x, long y){
	mpz_t y1; 
	mpz_init_set_si(y1, y); 
	mpz_sub(result, x, y1);
	mpz_mod(result, result, d);
	mpz_clear(y1); 
}

void SS_modSub_L_x(mpz_t result, long x, mpz_t y){
	mpz_t x1; 
	mpz_init_set_si(x1, x); 
	mpz_sub(result, x1, y);
	mpz_mod(result, result, d);
	mpz_clear(x1); 
}

void SS_modSub_L_y_array(mpz_t* result, mpz_t* x, long y, int size){
	for(int i=0; i<size; ++i)
		SS_modSub_L_y(result[i],x[i],y);
}

void SS_modSub_L_x_array(mpz_t* result, long x, mpz_t* y, int size){
	for(int i=0; i<size; ++i)
		SS_modSub_L_x(result[i],x,y[i]);
}


void SS_modSub_y_halfarray(mpz_t* result, mpz_t* x, mpz_t y, int size){
	for(int i=0; i<size; ++i)
		SS_modSub_basic(result[i],x[i],y);
}

void SS_modSub_x_halfarray(mpz_t* result, mpz_t x, mpz_t* y, int size){
	for(int i=0; i<size; ++i)
		SS_modSub_basic(result[i],x,y[i]);
}

//SS_ModPow
void SS_modPow_basic(mpz_t result, mpz_t base, mpz_t exponent){
	mpz_powm(result,base,exponent,d);
}

void SS_modPow_allarray(mpz_t* result, mpz_t* base, mpz_t* exponent, int size){
	for(int i = 0; i < size; i++)
		mpz_powmSS_modPow_basic(result[i],base[i],exponent[i],d);
}

void SS_modPow_L(mpz_t result, mpz_t base, long exponent){
	mpz_t value; 
	mpz_init_set_si(value, exponent); 
	SS_modAdd_L(value, value, (long)0); 
	mpz_powm(result, base, value, d);
	mpz_clear(value); 
}

void SS_modPow_L_array(mpz_t* result, mpz_t* base, long exponent, int size){
	for(int i=0; i<size; ++i)
		SS_modPow_L(result[i],base[i],exponent);
}
//SS_ModInv
void SS_modInv_basic(mpz_t result, mpz_t value){
	mpz_t temp;
	mpz_init(temp);
	mpz_sub_ui(temp, d, 2);
	SS_modPow_basic(result, value, temp);
	mpz_clear(temp); 
}

void SS_modInv_array(mpz_t* result, mpz_t* values, int size){
	for(int i = 0; i < size; i++)
		SS_modInv_basic(result[i],values[i]);
}
//SS_computeLagrangeWeight
void SS_computeLagrangeWeight(mpz_t * lagrangeWeight, int peers){
	mpz_t nom, denom, t1, t2, temp;
	mpz_init(nom);
	mpz_init(denom);
	mpz_init(t1);
	mpz_init(t2);
	mpz_init(temp);
	/*This part should be written in the main code to init lagrangeWeight, so dont forget to clear it

	lagrangeWeight = (mpz_t*)malloc(sizeof(mpz_t) * peers); 
	
	for(int i = 0; i < peers; i++)
		mpz_init(lagrangeWeight[i]);
	*/
	for(int peer = 0; peer < peers; peer++){
		int point = peer+1;
		mpz_set_ui(nom,1);
		mpz_set_ui(denom,1);

		for(int l = 0; l < peers; l++){
			if(l != peer){
				mpz_set_ui(t1, l+1);
				SS_modMul_basic(nom, nom, t1);
				mpz_set_ui(t2, point);
				SS_modSub_basic(temp, t1, t2);
				SS_modMul_basic(denom, denom, temp);
			}
		}
		SS_modInv_basic(temp, denom);
		SS_modMul_basic(lagrangeWeight[peer], nom, temp);
	}

	mpz_clear(nom); 
	mpz_clear(denom); 
	mpz_clear(t1); 
	mpz_clear(t2); 
	mpz_clear(temp); 
}
//SS_Mod

void SS_mod_array(mpz_t* result, mpz_t* a, mpz_t* m, int size){
	mpz_t tmp; 
	mpz_init(tmp); 
	for(int i=0; i<size; ++i){
		mpz_init_set_ui(tmp, 0); 
		mpz_add(tmp, a[i], m[i]); 
		if(mpz_cmp(tmp, d) > 0)
			mpz_sub(result[i], tmp, d);
		else{
			mpz_mod(result[i],a[i],m[i]);
			mpz_mod(result[i],result[i],d);
		}
	}
}

void SS_mod_basic(mpz_t* result, mpz_t* a, mpz_t m, int size){
        mpz_t tmp;
        mpz_init(tmp);
        for(int i=0; i<size; ++i){
                mpz_init_set_ui(tmp, 0);
                mpz_add(tmp, a[i], m);
                if(mpz_cmp(tmp, d) > 0)
                        mpz_sub(result[i], tmp, d);
                else{
                        mpz_mod(result[i],a[i],m);
                        mpz_mod(result[i],result[i],d);
                }
        }
}
//SS_ReconstructSecret

void SS_reconstructSecret_basic(mpz_t result, mpz_t* y, bool isMultiply, int peers, mpz_t * lagrangeWeight){
	mpz_t temp;
	mpz_init(temp);
	mpz_set_ui(result, 0); 
	for(int peer = 0; peer < peers; peer++){
		SS_modMul_basic(temp, y[peer], lagrangeWeight[peer]);
		SS_modAdd_basic(result,result, temp);
	}
	mpz_clear(temp); 
}

void SS_reconstructSecret_array(mpz_t* result, mpz_t** y, int size, bool isMultiply, int peers, mpz_t * lagrangeWeight){
	mpz_t temp;
	mpz_init(temp);
	for(int i = 0; i < size; i++)
		mpz_set_ui(result[i], 0);
	for(int i = 0; i < size; i++){
		for(int peer = 0; peer < peers; peer++){
			SS_modMul_basic(temp, y[peer][i], lagrangeWeight[peer]);
			SS_modAdd_basic(result[i],result[i], temp);
		}
	}
	mpz_clear(temp); 
}
