#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <gmp.h>
#include <stdint.h> 
#include "SS_Compute.h"

void Mod2M(mpz_t* result, mpz_t* shares1, int K, int M, int size, int threadID){
	int peers = 3;//ss->getPeers(); peers should be 3?
	mpz_t** R = (mpz_t**)malloc(sizeof(mpz_t*) * (M+2));
	mpz_t** resultShares = (mpz_t**)malloc(sizeof(mpz_t*) * peers); 
	mpz_t* U = (mpz_t*)malloc(sizeof(mpz_t) * size);
	mpz_t* shares = (mpz_t*)malloc(sizeof(mpz_t) * size);
	mpz_t* C = (mpz_t*)malloc(sizeof(mpz_t) * size); 
	
	//initialization
	mpz_t const2, constM, constK1, pow2M, pow2K1; 
	mpz_init_set_ui(const2, 2);
	mpz_init_set_ui(constM, M);
	mpz_init_set_ui(constK1, K-1);
	mpz_init(pow2M); 
	mpz_init(pow2K1); 
	for(int i = 0; i < M+2; i++){
		R[i] = (mpz_t*)malloc(sizeof(mpz_t) * size);
		for(int j = 0; j < size; j++)
			mpz_init(R[i][j]);
	}
  
	for(int i = 0; i < peers; i++){
                resultShares[i] = (mpz_t*)malloc(sizeof(mpz_t) * size);
                for(int j = 0; j < size; j++)
                        mpz_init(resultShares[i][j]);
        }

	for(int i = 0; i < size; i++){
		mpz_init(U[i]);
		mpz_init(C[i]); 
		mpz_init_set(shares[i], shares1[i]); 
	}

	SS_modPow_basic(pow2M, const2, constM);
	SS_modPow_basic(pow2K1, const2, constK1);
	
	// start comutation.
	Rand->PRandInt(K, M, size, C, threadID); //TODO
	SS_modMul_halfarray(C, C, pow2M, size); 
	Rand->PRandM(K, M, size, R, threadID);//TODO
	SS_modAdd_allarray(C, C, shares, size); 
	SS_modAdd_allarray(C, C, R[M], size);
	SS_modAdd_halfarray(C, C, pow2K1, size); 
	net.broadcastToPeers(C, size, resultShares, threadID);//TODO
	SS_reconstructSecret_array(C, resultShares, size, true);
	SS_mod_basic(C, C, pow2M, size); 
	B->doOperation(C, R, U, M, size, threadID);//TODO
	SS_modMul_halfarray(U, U, pow2M, size);
	SS_modAdd_allarray(result, C, U, size);
	SS_modSub_allarray(result, result, R[M], size);
	
	// free the memory
	for(int i = 0; i < M+2; i++){
		for(int j = 0; j < size; j++)
			mpz_clear(R[i][j]);
		free(R[i]); 
	}
	free(R); 

	for(int i = 0; i < peers; i++){
                for(int j = 0; j < size; j++)
                        mpz_clear(resultShares[i][j]);
		free(resultShares[i]); 
        }
	free(resultShares); 
	
	for(int i = 0; i < size; i++){
		mpz_clear(U[i]);
		mpz_clear(C[i]);
		mpz_clear(shares[i]);  
	}
	free(U); 
	free(C); 
	free(shares); 

	mpz_clear(const2);
	mpz_clear(constK1); 
	mpz_clear(constM); 
	mpz_clear(pow2M); 
	mpz_clear(pow2K1); 
} 
