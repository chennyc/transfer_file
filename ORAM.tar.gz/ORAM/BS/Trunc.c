#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <gmp.h>
#include <stdint.h> 
#include "SS_Compute.h"

 
void Trunc(mpz_t* result, mpz_t* shares1, int K, int M, int size, int threadID){
	mpz_t* shares = (mpz_t*)malloc(sizeof(mpz_t) * size);
	mpz_t const2, power, const2M, constInv2M;
	//initialization
	mpz_init(const2M);
	mpz_init(constInv2M);
	mpz_init_set_ui(const2, 2);
	mpz_init_set_ui(power, M);
	SS_modPow_basic(const2M, const2, power);
	SS_modInv_basic(constInv2M, const2M);
	//initialization
	for(int i = 0; i < size; i++)
		mpz_init_set(shares[i], shares1[i]);
	//start computation
	Mod->doOperation(result, shares, K, M, size, threadID); //TODO
	SS_modSub_allarray(result, shares, result, size);
	SS_modMul_halfarray(result, result, constInv2M, size);

	//free memory
	for(int i = 0; i < size; i++)
		mpz_clear(shares[i]); 
	free(shares);
	 
	mpz_clear(const2); 
	mpz_clear(power); 
	mpz_clear(const2M); 
	mpz_clear(constInv2M); 
}
