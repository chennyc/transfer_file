#ifndef netwrok
#define netwrok

struct memberlist
{
  int party_no;
  char memberadd[20];
  int keepfd;
};

struct message
{
  int stats;
//  mpz_t data;
  char mes[16];
};

struct aesmessage
{
  char mes[16];
};

void setconnect_a(struct memberlist *mp, struct message *msgp, int *neighfd);

void setconnect_b(struct memberlist *mp, struct message *msgp, int *neighfd);

void setconnect_c(struct memberlist *mp, struct message *msgp, int *neighfd);

#define LIS_PORT 34678
#define LIS_PORT2 34677
#define LOC_PORT 36478
#define LOC_PORT2 36477


#endif
