#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <wmmintrin.h>
#include <tmmintrin.h>
#include <gmp.h> 
#include <omp.h>
#include <gcrypt.h>
//#include "Encryption.h"
#include "Network.h"
#include "floram_util.h"
#include "Computation.h"
#include "AESNI_EN.h"
#include "BS.h"

#define ELE_NUM 1024
mpz_t d, d_base;
uint64_t * k_sys;
uint64_t * k1_prg;
uint64_t * k2_prg;
uint64_t * k3_prg;
uint8_t * plaintext_prg_k1;
uint8_t * plaintext_prg_k2;
uint8_t * plaintext_prg_k3;
uint8_t * plaintext_sys;
uint8_t * ciphertext_prg; //should be malloc later
int ell;

int main(int argc, char *argv[])
{
  /*Start Here*/
	char c = getopt(argc, argv, "a:b:c:"); //get the role of this party, a = 1, b = 3, c = 2
	
	__m128i key_aesen[20];

	mpz_init (d);
	mpz_init (d_base);
	mpz_ui_pow_ui (d_base, 2, 127);
	mpz_nextprime (d, d_base); //got a 128-bit prime

	//gmp_randstate_t state;
	//gmp_randinit_mt (state);
	//unsigned long int num = 2822;
	//gmp_randseed_ui (state, num);//the system-wide key
/*
	gmp_randstate_t k1_state;
	gmp_randstate_t k2_state;
	gmp_randstate_t k3_state;
	gmp_randinit_mt (k1_state);
	num = 2822;
	gmp_randseed_ui (k1_state, num);//the system-wide key


	gmp_randinit_mt (k2_state);
	num = 6853;
	gmp_randseed_ui (k2_state, num);//the system-wide key


	gmp_randinit_mt (k3_state);
	num = 9654;
	gmp_randseed_ui (k3_state, num);//the system-wide key
*/

	//uint64_t * k1_prg;
	//uint64_t * k2_prg;
	//uint64_t * k3_prg;
	
	uint8_t enc_key[]    = {0x3b, 0x7a, 0x12, 0x36, 0x2b, 0xab, 0xb2, 0xb6, 0xa6, 0xd7, 0x1f, 0x78, 0x09, 0xcf, 0x4f, 0x3c};//set the key of AES encyption for secure communication
	aes128_load_key(enc_key,key_aesen);
	
	printf("This is the key\n");
	plaintext_prg_k1 = malloc(16);
	plaintext_prg_k2 = malloc(16);
	plaintext_prg_k3 = malloc(16);
	plaintext_sys = malloc(16);
	//uint8_t * plaintext_prg_wa = malloc(16);
	//uint8_t * plaintext_prg_wb = malloc(16);
	ciphertext_prg = malloc(16);
	unsigned char testValue1[16]  = "abcdefghijklmnop";
	memset(plaintext_prg_k1, 0, 16*sizeof(uint8_t));
	memset(plaintext_prg_k2, 0, 16*sizeof(uint8_t));
	memset(plaintext_prg_k3, 0, 16*sizeof(uint8_t));
	memset(plaintext_sys, 0, 16*sizeof(uint8_t));
	//memset(plaintext_prg_wa, 0, 16*sizeof(uint8_t));
	//memset(plaintext_prg_wb, 0, 16*sizeof(uint8_t));
	//printf("This is the keyL:%u \n", *keyL);
	memcpy(plaintext_prg_k1, testValue1, 16*sizeof(uint8_t));
	memcpy(plaintext_prg_k2, testValue1, 16*sizeof(uint8_t));
	memcpy(plaintext_prg_k3, testValue1, 16*sizeof(uint8_t));
	//memcpy(plaintext_prg_wa, testValue1, 16*sizeof(uint8_t));
	//memcpy(plaintext_prg_wb, testValue1, 16*sizeof(uint8_t));
	printf("This is the key\n");
	uint8_t * key_raw = malloc(16);
	unsigned char key_raw_sys[16]  = "ijduybfhcidorufh";
	unsigned char key_raw_1[16]  = "abcdefghijklmnop";
	unsigned char key_raw_2[16]  = "jaskljdaisuehfhj";
	unsigned char key_raw_3[16]  = "opivjsidorupoipo";
	memcpy(key_raw, key_raw_sys, 16*sizeof(uint8_t));
	k_sys = offline_prg_keyschedule(key_raw);
	memcpy(key_raw, key_raw_1, 16*sizeof(uint8_t));
	k1_prg = offline_prg_keyschedule(key_raw);
	memcpy(key_raw, key_raw_2, 16*sizeof(uint8_t));
	k2_prg = offline_prg_keyschedule(key_raw);
	memcpy(key_raw, key_raw_3, 16*sizeof(uint8_t));
	k3_prg = offline_prg_keyschedule(key_raw);
	free(key_raw);
	printf("This is the key\n");
	int neighfd[3]={-1,-1,-1};
	
	ell = 10;	
	int j;

	mpz_t* alpha1 = Init_one (ell);
	mpz_t* alpha2 = Init_one (ell);
	mpz_t* alpha3 = Init_one (ell);
	convert_bit(100, alpha1, ell);
	convert_bit(200, alpha2, ell);
	convert_bit(300, alpha3, ell);
	printf("This is the key\n");

	struct memberlist memberp[4]={
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1}};
	struct memberlist *mp=memberp;
	struct message storemsg={0,"0123456789012345"};
	struct message *msgp=&storemsg;
	struct aesmessage storeaesmessage={"0123456789012345"};
	struct aesmessage *aesmsgp=&storeaesmessage;
	struct memberlist *p;
	p=mp;


	printf("input:%c\n", c);
	int i;
	switch(c)
	{
		case 'a': //a means party 1 ,L=2, R=3
		{
		//seeds=1024;
		//init_mem(Mem_L, seeds);
		//seeds=1025;
		//init_mem(Mem_R, seeds);
		p->party_no=1;
		p++;
		p->party_no=2;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=3;
		strcpy(p->memberadd, argv[optind]);
		};break;

		case 'b': //b party 2, ,L=1, R=3
		{
		//seeds=1024;
		//init_mem( Mem_L, seeds);
		//seeds=1025;
		//init_mem(Mem_R, seeds);


		p->party_no=2;
		p++;
		p->party_no=3;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=1;
		strcpy(p->memberadd, argv[optind]);
      		};break;

    		case 'c': //c party 3, L=1, R=2
      		{


		p->party_no=3;
		p++;
		p->party_no=1;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=2;
		strcpy(p->memberadd, argv[optind]);
      		};break;
    	}
 
  p=mp;
  printf("my name iis %d \n", p->party_no);
  p++;
  printf("this is no. %d the:%s\n", p->party_no, p->memberadd);
  p++;
  printf("this is no. %d the:%s\n", p->party_no, p->memberadd);

  p=mp;
   printf("my name is %d \n", p->party_no);


//init varibles that needed to be pass into the Gen()
	mpz_t* sigma_list = Init_one (ell); //fk_pub
	mpz_t* tau0_list = Init_one (ell);
	mpz_t* tau1_list = Init_one (ell);
        mpz_t gamma;
	mpz_init (gamma);

        mpz_t* fk_3= Init_one (2); //[fk]
	mpz_t* fk_1= Init_one (2);
	mpz_t* fk_2= Init_one (2);

        mpz_t beta_3, beta_1,  beta_2;
	mpz_init (beta_3);
	mpz_init (beta_1);
	mpz_init (beta_2);

	mpz_set_ui(beta_3, 0); //just try to write 0, beta_1 = beta =1
	mpz_set_ui(beta_1, 1); //just try to write 0
	mpz_set_ui(beta_2, 0);
//---------
	Gen_three(sigma_list, gamma, tau0_list, tau1_list, fk_1, fk_2, fk_3, beta_1, beta_2, beta_3, alpha1, alpha2, alpha3, neighfd, p, mp, k1_prg, k2_prg, k3_prg, k_sys, msgp, aesmsgp, key_aesen);

	for(j=0;j<ell;j++)
	{
			//printf("this is ok %d--\n", j);
		mpz_clear(sigma_list[j]);
		mpz_clear(tau0_list[j]);
		mpz_clear(tau1_list[j]);
	}
	mpz_clear(gamma);
	mpz_clear(fk_1[0]);
	mpz_clear(fk_1[1]);
	mpz_clear(fk_2[0]);
	mpz_clear(fk_2[1]);
	mpz_clear(fk_3[0]);
	mpz_clear(fk_3[1]);
	mpz_clear(beta_1);
	mpz_clear(beta_2);
	mpz_clear(beta_3);

	for(j=0;j<ell;j++)
	{
		//printf("this is ok %d--\n", j);
		mpz_clear(alpha1[j]);
		//printf("this is still ok %d--\n", j);
		mpz_clear(alpha2[j]);
		//printf("this is still ok %d--\n", j);
		mpz_clear(alpha3[j]);
		//printf("this is still ok %d--\n", j);
	}
	//for (i = 0; i < ELE_NUM; i++) {
   	//mpz_clear(Mem_L[i]);
	//mpz_clear(Mem_R[i]);
	//}
 	mpz_clear(d_base);
	mpz_clear(d);
	free(plaintext_prg_k1);
	free(plaintext_prg_k2);
	free(plaintext_prg_k3);
	//free(plaintext_prg_wa);
	//free(plaintext_prg_wb);
	free(plaintext_sys);
	free(ciphertext_prg);
	//printf("this is ok--\n");
	free(key_raw);
	free(k1_prg);
	free(k2_prg);
	free(k3_prg);
	free(k_sys);
	//printf("this is ok--\n");


  return 0;
}
