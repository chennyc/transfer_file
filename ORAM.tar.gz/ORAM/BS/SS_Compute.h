#ifndef SS_Compute
#define SS_Compute

//SS_ModMul
void SS_modMul_basic(mpz_t result, mpz_t x, mpz_t y);


void SS_modMul_allarray(mpz_t* result, mpz_t* x, mpz_t* y, int size);


void SS_modMul_halfarray(mpz_t* result, mpz_t* x, mpz_t y, int size);


void SS_modMul_L(mpz_t result, mpz_t x, long y);


void SS_modMul_L_array(mpz_t* result, mpz_t* x, long y, int size);


//SS_ModAdd
void SS_modAdd_basic(mpz_t result, mpz_t x, mpz_t y);


void SS_modAdd_allarray(mpz_t* result, mpz_t* x, mpz_t* y, int size);


void SS_modAdd_L(mpz_t result, mpz_t x, long y);


void SS_modAdd_L_array(mpz_t* result, mpz_t*x, long y, int size);


void SS_modAdd_halfarray(mpz_t* result, mpz_t* x, mpz_t y, int size);

//SS_ModSub
void SS_modSub_basic(mpz_t result, mpz_t x, mpz_t y);


void SS_modSub_allarray(mpz_t* result, mpz_t* x, mpz_t* y, int size);



void SS_modSub_L_y(mpz_t result, mpz_t x, long y);


void SS_modSub_L_x(mpz_t result, long x, mpz_t y);


void SS_modSub_L_y_array(mpz_t* result, mpz_t* x, long y, int size);


void SS_modSub_L_x_array(mpz_t* result, long x, mpz_t* y, int size);



void SS_modSub_y_halfarray(mpz_t* result, mpz_t* x, mpz_t y, int size);


void SS_modSub_x_halfarray(mpz_t* result, mpz_t x, mpz_t* y, int size);


//SS_ModPow
void SS_modPow_basic(mpz_t result, mpz_t base, mpz_t exponent);


void SS_modPow_allarray(mpz_t* result, mpz_t* base, mpz_t* exponent, int size);


void SS_modPow_L(mpz_t result, mpz_t base, long exponent);


void SS_modPow_L_array(mpz_t* result, mpz_t* base, long exponent, int size);

//SS_ModInv
void SS_modInv_basic(mpz_t result, mpz_t value);

void SS_modInv_array(mpz_t* result, mpz_t* values, int size);

//SS_Mod

void SS_mod_array(mpz_t* result, mpz_t* a, mpz_t* m, int size);

void SS_mod_basic(mpz_t* result, mpz_t* a, mpz_t m, int size);

//SS_computeLagrangeWeight
void SS_computeLagrangeWeight(mpz_t * lagrangeWeight, int peers);

//SS_ReconstructSecret

void SS_reconstructSecret_basic(mpz_t result, mpz_t* y, bool isMultiply, int peers, mpz_t * lagrangeWeight);


void SS_reconstructSecret_array(mpz_t* result, mpz_t** y, int size, bool isMultiply, int peers, mpz_t * lagrangeWeight);



#endif
