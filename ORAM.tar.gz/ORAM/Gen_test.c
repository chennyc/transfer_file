#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <fcntl.h> 
#include "gmp.h" 
#define LIS_PORT 34678
#define LOC_PORT 36478
#define ELE_NUM 1024

mpz_t d, d_base;
//gmp_randstate_t k1_state;
//gmp_randstate_t k2_state;
//gmp_randstate_t k3_state;
struct memberlist
{
  int party_no;
  char memberadd[20];
  int keepfd;
};

struct message
{
  int stats;
//  mpz_t data;
  char mes[10];
};

struct send_mpz
{
	int mpz_len;
	char mpz_str[0];
}__attribute((packed));

mpz_t* Init_one (int num){

	int i;
	mpz_t * op=(mpz_t*)malloc(sizeof(mpz_t) * num);
	for(i = 0; i < num; i++)
      	mpz_init(op[i]);
	return op;
}

void init_mem(mpz_t* Mem, int seed)
{
	mpz_t seeds;
	mpz_init(seeds);
	mpz_set_d (seeds, seed);
 	gmp_randstate_t state;
	gmp_randinit_mt (state);
	gmp_randseed (state, seeds);
	int i;
	for(i=0;i<ELE_NUM;i++)
	{
		 mpz_urandomm (Mem[i], state, d);
	
	}
	mpz_clear(seeds);
	gmp_randclear(state);
}

void setconnect_a(struct memberlist *mp, struct message *msgp, int *neighfd)
{
  
printf("this is in a \n");
struct memberlist *p;

  int connfd, lisfd, sock_fd;
  p=mp;
  p++;
  char msgbuf[sizeof(struct message)];


  struct sockaddr_in server_addr;

  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }



  bzero(&server_addr, sizeof(struct sockaddr_in));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(LIS_PORT);

  if (bind(sock_fd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr)) == -1) {
    perror("bind error");
  }
printf("this is after bind \n");
  //int listen_flag = 0;

  if(listen(sock_fd, 2) == -1) {
    perror("listen error");
    exit(1);
  }

printf("this is after listen \n");

lisfd = accept(sock_fd, (struct sockaddr *)NULL, NULL);
  if ( lisfd == -1) {
    perror("accpet error");
    exit(1);
  }

printf("this is after accept \n");

  int flags  = fcntl(lisfd,F_GETFL,0);       
  fcntl(lisfd,F_SETFL,flags&~O_NONBLOCK);    

  memset(msgbuf,0,sizeof(msgbuf));
  recv(lisfd,msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));

  if (msgp->stats != 10)  //10 means party-2 is online now.
    {
      perror("recv error");
      exit(1);
    }


  printf("this is after rev\n");

  p=mp+2;
  p->keepfd=lisfd;
  p=mp+1;
  char * servInetAddr = p->memberadd;
  printf("this is servInetAddr: %s \n", servInetAddr);
  int servPort = LIS_PORT;
  socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr, claddr;
  connfd = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);
  p->keepfd=connfd;
  bzero(&claddr, sizeof(claddr));
  claddr.sin_family = AF_INET;
  claddr.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr.sin_port = htons(LOC_PORT);
  bind(connfd, (struct sockaddr*)&claddr, socklen);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr, &servaddr.sin_addr);
  if (connect(connfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
    perror("connect error");
  }
  printf("this is after connection\n");
/*
  msgp->stats=mp->party_no;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(connfd,msgbuf,sizeof(*msgp),0);
  p->keepfd=connfd;
*/

/*
p=mp+1;
if(close(p->keepfd)<0)
{
    perror("close1 error");
    exit(1);
}
p++;
if(close(p->keepfd)<0)
{
    perror("close2 error");
    exit(1);
}
*/
  neighfd[1]= connfd;
  neighfd[2]= lisfd;
}



void setconnect_b(struct memberlist *mp, struct message *msgp, int *neighfd)
{
  struct memberlist *p;

  int connfd, lisfd, sock_fd;
  p=mp;
  p++;
  char msgbuf[sizeof(struct message)];


  // the party 2 will try to connect party 3 at first.
  char * servInetAddr = p->memberadd;
  //printf("this is servInetAddr: %s \n", servInetAddr);
  int servPort = LIS_PORT;
  socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr, claddr;
  connfd = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);

  bzero(&claddr, sizeof(claddr));
  claddr.sin_family = AF_INET;
  claddr.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr.sin_port = htons(LOC_PORT);
  bind(connfd, (struct sockaddr*)&claddr, socklen);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr, &servaddr.sin_addr);
  if (connect(connfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
    perror("connect error");
  }

  p->keepfd=connfd;

printf("this is after connect\n");


  //then party 2 wait for the party 1
  struct sockaddr_in server_addr;

  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }

  bzero(&server_addr, sizeof(struct sockaddr_in));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(LIS_PORT);

  if (bind(sock_fd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr)) == -1) {
    perror("bind error");
  }

  //int listen_flag = 0;

  if(listen(sock_fd, 2) == -1) {
    perror("listen error");
    exit(1);
  }



msgp->stats=2;
memset(msgbuf,0,sizeof(msgbuf));
memcpy(msgbuf,msgp,sizeof(msgp)); 
send(connfd,msgbuf,sizeof(msgbuf),0);


printf("this is after listen and before accept\n");



lisfd = accept(sock_fd, (struct sockaddr *)NULL, NULL);

  if (lisfd == -1) {
    perror("accpet error");
    exit(1);
  }
printf("this is after accept\n");
  //int flags  = fcntl(lisfd,F_GETFL,0);       
  //fcntl(lisfd,F_SETFL,flags&~O_NONBLOCK);    

  //memset(msgbuf,0,sizeof(msgbuf));
  //recv(lisfd,msgbuf,sizeof(*msgp),0 );
  //memset(msgp,0,sizeof(*msgp));
  //memcpy(msgp,msgbuf,sizeof(*msgp));

  //if (msgp->stats != 2)  //2 means the accepted party is 2.
  //{
  //perror("recv error");
  //exit(1);
  //}

  p=mp+2;
  p->keepfd=lisfd;
  //party 3 needs to tell party 1 that party 2 is online now.
  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=10;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  //send(connfd,msgbuf,sizeof(*msgp),0);
/*
p=mp+1;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
p++;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
*/
  neighfd[1]= connfd;
  neighfd[2]= lisfd;
}

void setconnect_c(struct memberlist *mp, struct message *msgp, int *neighfd)
{
  struct memberlist *p;

  int connfd, lisfd, sock_fd;
  p=mp;
  p++;
  char msgbuf[sizeof(struct message)];


  // the party 3 will try to connect party 1 at first.
  char * servInetAddr = p->memberadd;
  //printf("this is servInetAddr: %s \n", servInetAddr);
  int servPort = LIS_PORT;
  socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr, claddr;
  connfd = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);

  bzero(&claddr, sizeof(claddr));
  claddr.sin_family = AF_INET;
  claddr.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr.sin_port = htons(LOC_PORT);
  bind(connfd, (struct sockaddr*)&claddr, socklen);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr, &servaddr.sin_addr);
  if (connect(connfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
    perror("connect error");
  }

  p->keepfd=connfd;


  //then party 3 wait for the party 2
  struct sockaddr_in server_addr;

  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }

  bzero(&server_addr, sizeof(struct sockaddr_in));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(LIS_PORT);

  if (bind(sock_fd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr)) == -1) {
    perror("bind error");
  }

  //int listen_flag = 0;

  if(listen(sock_fd, 2) == -1) {
    perror("listen error");
    exit(1);
  }

  if ((lisfd = accept(sock_fd, (struct sockaddr *)NULL, NULL)) == -1) {
    perror("accpet error");
    exit(1);
  }
printf("this is after acceot\n");
  //int flags  = fcntl(lisfd,F_GETFL,0);       
  //fcntl(lisfd,F_SETFL,flags&~O_NONBLOCK);    

  memset(msgbuf,0,sizeof(msgbuf));
  recv(lisfd,msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));

  if (msgp->stats != 2)  //2 means the accepted party is 2.
    {
      perror("recv error");
      exit(1);
    }
printf("this is after recving a message from 2\n");
  p=mp+2;
  p->keepfd=lisfd;
  //party 3 needs to tell party 1 that party 2 is online now.
  memset(msgp,0,sizeof(*msgp));
  msgp->stats=10;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(connfd,msgbuf,sizeof(*msgp),0);

/*
p=mp+1;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
p++;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
*/
  neighfd[1]= connfd;
  neighfd[2]= lisfd;
}




int main(int argc, char *argv[])
{
  /*Start Here*/

	mpz_init (d);
	mpz_init (d_base);
	mpz_ui_pow_ui (d_base, 2, 127);
	mpz_nextprime (d, d_base); //got a 128-bit prime
/*
	gmp_randstate_t state;
	gmp_randinit_mt (state);
	unsigned long int num = 2822;
	gmp_randseed_ui (state, num);//the system-wide key

	gmp_randstate_t k1_state;
	gmp_randstate_t k2_state;
	gmp_randstate_t k3_state;
	gmp_randinit_mt (k1_state);
	num = 2822;
	gmp_randseed_ui (k1_state, num);//the system-wide key


	gmp_randinit_mt (k2_state);
	num = 6853;
	gmp_randseed_ui (k2_state, num);//the system-wide key


	gmp_randinit_mt (k3_state);
	num = 9654;
	gmp_randseed_ui (k3_state, num);//the system-wide key
*/

	mpz_t* Mem_L = Init_one (ELE_NUM);
	mpz_t* Mem_R = Init_one (ELE_NUM);
	int seeds;

	int neighfd[3]={-1,-1,-1};

	int ell;	

	struct memberlist memberp[4]={
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1}};
	struct memberlist *mp=memberp;
	struct message storemsg={0,"asd.asd"};
	struct message *msgp=&storemsg;

	struct memberlist *p;
	p=mp;

	char c = getopt(argc, argv, "a:b:c:");
	printf("input:%c\n", c);
	int i;
	switch(c)
	{
		case 'a': //a means party 1 ,L=2, R=3
		{
		seeds=1024;
		init_mem(Mem_L, seeds);
		seeds=1025;
		init_mem(Mem_R, seeds);
		p->party_no=1;
		p++;
		p->party_no=2;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=3;
		strcpy(p->memberadd, argv[optind]);
		};break;

		case 'b': //b party 2, ,L=1, R=3
		{
		seeds=1024;
		init_mem( Mem_L, seeds);
		seeds=1025;
		init_mem(Mem_R, seeds);

		for(i=0;i<ELE_NUM;i++)
		{
		mpz_add(Mem_L[i],Mem_R[i],Mem_L[i]);
		mpz_sub_ui(Mem_L[i], Mem_L[i], i);
		mpz_mod (Mem_L[i], Mem_L[i], d);
		}

		p->party_no=2;
		p++;
		p->party_no=3;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=1;
		strcpy(p->memberadd, argv[optind]);
      		};break;

    		case 'c': //c party 3, L=1, R=2
      		{
		seeds=1025;
		init_mem(Mem_L, seeds);
		seeds=1024;
		init_mem(Mem_R, seeds);

		for(i=0;i<ELE_NUM;i++)
		{
		mpz_add(Mem_L[i],Mem_R[i],Mem_L[i]);
		mpz_sub_ui(Mem_L[i], Mem_L[i], i);
		mpz_mod (Mem_L[i], Mem_L[i], d);
		}

		p->party_no=3;
		p++;
		p->party_no=1;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=2;
		strcpy(p->memberadd, argv[optind]);
      		};break;
    	}
 
  p=mp;
  printf("my name iis %d \n", p->party_no);
  p++;
  printf("this is no. %d the:%s\n", p->party_no, p->memberadd);
  p++;
  printf("this is no. %d the:%s\n", p->party_no, p->memberadd);

  p=mp;
   printf("my name is %d \n", p->party_no);

	mpz_t test_int;
	mpz_init (test_int);
	char mpz_str[10];
	struct send_mpz *sample_send;
	char msgbuf[1024];
  switch(p->party_no)
    {
    case 1://this is a=1
	//printf("this is a--\n");
	setconnect_a(mp,msgp,neighfd);
	mpz_set_si(test_int, 5);
	gmp_printf("My value is %Zd\n", test_int);
	mpz_get_str(mpz_str, 10, test_int);
	printf("My str is %s\n", mpz_str);
	
	int sample_len = sizeof(*mpz_str);
	printf("My send str's len is %d\n", sample_len);
	sample_send = (struct send_mpz*)malloc(sizeof(struct send_mpz)+sizeof(char)*sample_len);
	strcpy(sample_send->mpz_str, mpz_str);
	printf("My str is %s\n", sample_send->mpz_str);
	sample_send->mpz_len = sample_len;


	memset(msgbuf,0,sizeof(msgbuf));
	memcpy(msgbuf,sample_send,sizeof(*sample_send)); 
	send(neighfd[1],msgbuf,sizeof(*sample_send),0);
	//result

      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
      break;

    case 2:
      setconnect_b(mp,msgp,neighfd); //party b is the party 3
	mpz_set_si(test_int, 2);
      
	sample_send = (struct send_mpz*)malloc(sizeof(struct send_mpz)+sizeof(char)*2);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[2],msgbuf,sizeof(*sample_send),0 );
  memset(sample_send,0,sizeof(*sample_send));
  memcpy(sample_send,msgbuf,sizeof(*sample_send));	
	printf("My recv str's len is %d\n", sample_send->mpz_len);
	printf("My recv str is %s\n", sample_send->mpz_str);
	mpz_set_str(test_int, sample_send->mpz_str, 10);
	gmp_printf("My recv value is %Zd\n", test_int);
	p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
      break;

    case 3: //this party c is the party 2
      setconnect_c(mp,msgp,neighfd);
	mpz_set_si(test_int, 3);
      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
      break;

    }
 	mpz_clear(d_base);
	mpz_clear(d);
	for (i = 0; i < ELE_NUM; i++) {
   	mpz_clear(Mem_L[i]);
	mpz_clear(Mem_R[i]);
	}


  return 0;
}
