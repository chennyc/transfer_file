#ifndef AESNI_EN
#define AESNI_EN

# define ELL 10
# define ELE_NUM 1024
#endif
