#include "stdint.h"
#include "string.h"
#include "stdlib.h"
#include "gmp.h"
#include "openssl/evp.h"
#include "openssl/aes.h"
#include "unistd.h"
#include <wmmintrin.h>
#include <tmmintrin.h>
#include "floram_util.h"
#include <sys/time.h>
//# define ELL 20// \ell, the length of an element's index, will be defined latter.

//globle moduls
mpz_t d, d_base;

//void aes_encrypt(char *plaintext, int plaintext_len, mpz_t *key, mpz_t *ciper_tmp);
//int find_least_signf(mpz_t op);
mpz_t* Init_one (int num);
mpz_t** Init_two (int num);
//unsigned char testValue1[16];
uint64_t * k_sys;
uint8_t * ciphertext_1;
uint8_t * ciphertext_2;
uint8_t * ciphertext_3;
uint8_t * ciphertext_4;
void prg_aes_ni_quad(uint64_t * keyed_a, mpz_t alpha_1, mpz_t alpha_2, mpz_t alpha_3, mpz_t alpha_4, uint8_t * plaintext_1, uint8_t * plaintext_2, uint8_t * plaintext_3, uint8_t * plaintext_4)
{
//uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
//	printf("this is prg\n");
	offline_prg(ciphertext_1, plaintext_1, keyed_a);
//	printf("this is prg\n");
	offline_prg(ciphertext_2, plaintext_2, keyed_a);
	offline_prg(ciphertext_3, plaintext_3, keyed_a);
	offline_prg(ciphertext_4, plaintext_4, keyed_a);
//	memcpy(plaintext_prg,ciphertext_prg,16*sizeof(uint8_t));
	mpz_import(alpha_1, 16, 1, sizeof(*ciphertext_1), 0, 0, ciphertext_1);
	mpz_import(alpha_2, 16, 1, sizeof(*ciphertext_2), 0, 0, ciphertext_2);
	mpz_import(alpha_3, 16, 1, sizeof(*ciphertext_3), 0, 0, ciphertext_3);
	mpz_import(alpha_4, 16, 1, sizeof(*ciphertext_4), 0, 0, ciphertext_4);
//	printf("this is prg\n");
	//mpz_mod (alpha, alpha, d);
}

int Eval_gen(int ele_num, mpz_t gamma, mpz_t w_0, mpz_t t_0, mpz_t *sigma, mpz_t **tau, mpz_t *w_T, mpz_t *t_T, int op) 
{
//	printf("this is eval_genn\n");
  struct timeval start;
  struct timeval pause;
  struct timeval end;
  unsigned long timer1;
  unsigned long timer2;
  mpz_t tmp, s_0, s_1, v_0, v_1, read_sum;
  mpz_init(tmp);
  mpz_init(s_0);
  mpz_init(s_1);
  mpz_init(v_0);
  mpz_init(v_1);
  mpz_init(read_sum);
//printf("this is eval_genn\n");
  int i, j, p_last, p_curt, offset, lev_elemt;
  p_last = 0;
  p_curt = 0;
  lev_elemt = 1;
  
  mpz_set(w_T[0],w_0);
  mpz_set(t_T[0],t_0);

//	printf("this is eval_gennn\n");
	//uint8_t * key_prg_w = malloc(16);

	//unsigned char testValue1 = "abcdefghijklmnop";
	uint8_t * plaintext_1 = malloc(16);
	uint8_t * plaintext_2 = malloc(16);
	uint8_t * plaintext_3 = malloc(16);
	uint8_t * plaintext_4 = malloc(16);
	//memset(plaintext_prg_w, 0, 16*sizeof(uint8_t));	

	//memcpy(plaintext_prg_w, testValue1, 16*sizeof(uint8_t));
  //gmp_randstate_t state;
//	printf("this is eval_gen\n");
gettimeofday(&start,NULL);//stop timer here
#pragma omp parallel for num_threads(16)
  for(i=1; i < ELL; i++)
    {
	//long long count=0;
	//count++;

	//if(i==9)printf("this is eval_gen of %d\n", i);
      p_last = p_curt - lev_elemt + 1;     
      for (j=0;j < lev_elemt; j++)
        {
//	printf("i= %d j = %d lev_elment=%d p_curt=%d\n", i, j, lev_elemt,p_curt);
	//count++;
//	printf("this is eval_gen,\n");

          offset = j/2;
	//memcpy(plaintext_prg_w, testValue1, 16*sizeof(uint8_t));
          // s_T[p_curt], v_T[p_curt] <- PRG(w_T[p_last+offset]);
	  //gmp_randinit_mt (state);
	  //gmp_randseed (state, w_T[p_last+offset]);
	mpz_export(plaintext_1, NULL, 1, sizeof(*plaintext_1), 0, 0, w_T[p_last+offset]);
	memcpy(plaintext_2, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_3, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_4, plaintext_1, 16*sizeof(uint8_t));	
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
//printf("this is eval_gen,\n");
	plaintext_2[0] = plaintext_2[0] + 1;
	plaintext_3[0] = plaintext_3[0] + 2;
	plaintext_4[0] = plaintext_4[0] + 3;
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
	//k_sys = offline_prg_keyschedule(key_prg_w);
	prg_aes_ni_quad(k_sys, s_0, s_1, v_0, v_1, plaintext_1, plaintext_2, plaintext_3, plaintext_4);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
//printf("this is eval_gen,\n");
          //mpz_set(tmp,s_T[p_curt][0]);
          mpz_addmul (s_0, t_T[p_last+offset], sigma[i]);
	  mpz_mod (w_T[2*p_curt+1], s_0, d);
	//printf("j= %d, %d and%d\n",j, 2*p_curt+1,2*p_curt+2);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
         // mpz_set(s_1,s_T[p_curt][1]);
          mpz_addmul (s_1, t_T[p_last+offset], sigma[i]);
	//if(i==9)printf("this is eval_gen of %d and %d\n", i, p_curt);
	  mpz_mod (w_T[2*p_curt+2], s_1, d);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
          //mpz_set(tmp,v_T[p_curt][0]);
          mpz_addmul (v_0, t_T[p_last+offset], tau[i][0]);
	  mpz_mod (t_T[2*p_curt+1], v_0, d);
	//if(i==9)printf("this is eval_gen of %d abd %d\n", i, j);
          //mpz_set(tmp,v_T[p_curt][1]);
          mpz_addmul (v_1, t_T[p_last+offset], tau[i][1]);
	  mpz_mod (t_T[2*p_curt+2], v_1, d);   
          p_curt++;     
        }
	lev_elemt = lev_elemt * 2;
    }

	p_last = p_curt - lev_elemt + 1;
//printf("the first father node is %d\n",p_last);

gettimeofday(&pause,NULL);//stop timer here
timer1 = 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
printf("timer 1= %ld us\n",timer1);


#pragma omp parallel for num_threads(16)
  for(i=0; i < ele_num/2; i++)
    {
	mpz_export(plaintext_1, NULL, 1, sizeof(*plaintext_1), 0, 0, w_T[p_last]);
	memcpy(plaintext_2, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_3, plaintext_1, 16*sizeof(uint8_t));
	memcpy(plaintext_4, plaintext_1, 16*sizeof(uint8_t));	
	plaintext_2[0] = plaintext_2[0] + 1;
	plaintext_3[0] = plaintext_3[0] + 2;
	plaintext_4[0] = plaintext_4[0] + 3;
	prg_aes_ni_quad(k_sys, s_0, s_1, v_0, v_1, plaintext_1, plaintext_2, plaintext_3, plaintext_4);

	if(op == 0)// op=1 means this operation is read
	{
          //mpz_set(tmp,s_0);
          mpz_addmul (s_0, t_T[p_last], sigma[ELL]); //ELL here maybe wrong
	  mpz_mod (s_0, s_0, d); //s_0 = w^ll of left(0) child

          //mpz_set(tmp,s_T[p_curt][1]);
          mpz_addmul (s_1, t_T[p_last], sigma[ELL]);
	  mpz_mod (s_1, s_1, d);//s_1 = w^ll of right(1) child
	}
          //mpz_set(v_0,v_T[p_curt][0]);
          mpz_addmul (v_0, t_T[p_last], tau[ELL][0]);
	  mpz_mod (v_0, v_0, d);//v_0 = t^ll of left(0) child

          //mpz_set(tmp,v_T[p_curt][1]);
          mpz_addmul (v_1, t_T[p_last], tau[ELL][1]);
	  mpz_mod (v_1, v_1, d); //v_1 = t^ll of right(1) child
	if(op == 0)// op=1 means this operation is read
	{
	//mpz_set(tmp,s_0);//srore the 
        mpz_addmul (s_0, v_0, gamma); //s_0 = y_T
        mpz_addmul (s_1, v_1, gamma); 
	//write the y_T into memory.
	}
	else
	{
	        mpz_addmul (read_sum, read_sum, v_0); 
	        mpz_addmul (read_sum, read_sum, v_1); 
	}
    }
		//output the read_sum if needed.
  mpz_clear(tmp);
  mpz_clear(s_0);
  mpz_clear(s_1);
  mpz_clear(v_0);
  mpz_clear(v_1);
  mpz_clear(read_sum);
  //free(key_prg_w );
  //free(plaintext_prg_w);
	printf("this is eval_genn\n");

gettimeofday(&end,NULL);//stop timer here
timer2 = 1000000 * (end.tv_sec-pause.tv_sec)+ end.tv_usec-pause.tv_usec;
printf("timer 2= %ld us\n",timer2);
  return 0;

}
/*
int *Eval_read(mpz_t *sigma, mpz_t **tau, mpz_t gamma, int index, mpz_t y_T, mpz_t tt_T, mpz_t *s_T, mpz_t *v_T, mpz_t *w_T, mpz_t *t_T, int p_last)
{ //                                                                                                 
  int i, j, offset;
  mpz_t sl_T, vl_T, wl_T, tl_T, tmp;                                                                                          

	uint8_t * key_prg_w = malloc(16);
	unsigned char testValue1 = "abcdefghijklmnop";
	uint8_t * plaintext_prg_w = malloc(16);
	memset(plaintext_prg_w, 0, 16*sizeof(uint8_t));
	//memcpy(plaintext_prg_w, testValue1, 16*sizeof(uint8_t));

  mpz_init (tmp);
  mpz_init (sl_T);
  mpz_init (vl_T);
  mpz_init (wl_T);
  mpz_init (tl_T);


  offset = index/2;
  //gmp_randstate_t state;
  //gmp_randinit_mt (state);
  //gmp_randseed (state, w_T[p_last+offset]);
  mpz_export(key_prg_w, NULL, 1, sizeof(*key_prg_w), 0, 0, w_T[p_last+offset]);


  //mpz_urandomm (sl_T, state, d);
  //mpz_urandomm (vl_T, state, d);

	k_sys = offline_prg_keyschedule(key_prg_w);
		if(index%2 == 0)
		{

	//mpz_urandomm (s_T[p_curt], state, d);
	//mpz_urandomm (v_T[p_curt], state, d);

		prg_aes_ni(k_sys, sl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, vl_T, plaintext_prg_w);
		//prg_aes_ni(k_sys2, sj1_2, plaintext_prg_wa);
		//prg_aes_ni(k_sys2, vj1_2, plaintext_prg_wa);
		}
		else
		{
		prg_aes_ni(k_sys, sl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, vl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, sl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, vl_T, plaintext_prg_w);

		}



  mpz_set(tmp,vl_T);
  mpz_addmul (tmp, t_T[p_last+offset], tau[ELL][index%2]);
  mpz_mod (tl_T, tmp, d);

  mpz_set(tt_T, tl_T);

  mpz_clear (tmp);
  mpz_clear (sl_T);
  mpz_clear (vl_T);
  mpz_clear (wl_T);
  mpz_clear (tl_T);
  free(key_prg_w );
  free(plaintext_prg_w);
 // gmp_randclear(state);
}

int *Eval_write(mpz_t *sigma, mpz_t **tau, mpz_t gamma, int index, mpz_t y_T, mpz_t tt_T, mpz_t *s_T, mpz_t *v_T, mpz_t *w_T, mpz_t *t_T, int p_last)
{ //

  printf("this is eval");
  int i, j, offset;
  mpz_t sl_T, vl_T, wl_T, tl_T, tmp;
	uint8_t * key_prg_w = malloc(16);
	unsigned char testValue1 = "abcdefghijklmnop";
	uint8_t * plaintext_prg_w = malloc(16);
	memset(plaintext_prg_w, 0, 16*sizeof(uint8_t));
	//memcpy(plaintext_prg_w, testValue1, 16*sizeof(uint8_t));

	
	mpz_init (tmp);
	mpz_init (sl_T);
	mpz_init (vl_T);
	mpz_init (wl_T);
	mpz_init (tl_T);

	offset = index/2;
	//gmp_randstate_t state;
	//gmp_randinit_mt (state);
	//gmp_randseed (state, w_T[p_last+offset]);
	mpz_export(key_prg_w, NULL, 1, sizeof(*key_prg_w), 0, 0, w_T[p_last+offset]);
	
	//mpz_urandomm (sl_T, state, d);
	//mpz_urandomm (vl_T, state, d);
		k_sys = offline_prg_keyschedule(key_prg_w);
		if(index%2 == 0)
		{

	//mpz_urandomm (s_T[p_curt], state, d);
	//mpz_urandomm (v_T[p_curt], state, d);

		prg_aes_ni(k_sys, sl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, vl_T, plaintext_prg_w);
		//prg_aes_ni(k_sys2, sj1_2, plaintext_prg_wa);
		//prg_aes_ni(k_sys2, vj1_2, plaintext_prg_wa);
		}
		else
		{
		prg_aes_ni(k_sys, sl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, vl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, sl_T, plaintext_prg_w);
		prg_aes_ni(k_sys, vl_T, plaintext_prg_w);

		}



	mpz_set(tmp,sl_T);
	mpz_addmul (tmp, t_T[p_last+offset], sigma[ELL]);
	mpz_mod (wl_T, tmp, d);

	mpz_set(tmp,vl_T);
	mpz_addmul (tmp, t_T[p_last+offset], tau[ELL][index%2]);
	mpz_mod (tl_T, tmp, d);

        mpz_addmul (wl_T, tl_T, gamma);
	mpz_mod (y_T, wl_T, d);

	mpz_set(tt_T, tl_T);

	mpz_clear (tmp);
        mpz_clear (sl_T);
        mpz_clear (vl_T);
        mpz_clear (wl_T);
        mpz_clear (tl_T);
  free(key_prg_w );
  free(plaintext_prg_w);
//	gmp_randclear(state);
}
*//*
int *Gen(int index, mpz_t beta, mpz_t w_0, mpz_t t_0, mpz_t *sigma, mpz_t **tau, mpz_t gamma){

	mpz_t** s_T = Init_two (ELL+1);
        mpz_t** v_T = Init_two (ELL+1);
   	mpz_t* w = Init_one (ELL+1);
   	mpz_t* t = Init_one (ELL+1);
	
	int i, j;

.
.
.

	mpz_set_d(gamma,1);
        for(i = 0; i < ELL+1; i++)
	  {
	    mpz_set_d(sigma[i], 1);
	    mpz_set_d(w[i], 1);
	    mpz_set_d(t[i], 1);
	    for(j = 0; j < 2; j++){
	      mpz_set_d(tau[i][j], 1);
	    }

	  }
	mpz_set(w_0,w[0]); // w_0 in fk
	mpz_set(t_0,t[0]); // t_0 in fk

	
	for(i = 0; i < ELL+1; i++){
		mpz_clear(w[i]); 
		mpz_clear(t[i]); 
		mpz_clear(*s_T[i]);
		mpz_clear(*v_T[i]);
	}

}
*/
mpz_t* Init_one (int num){

	int i;
	mpz_t * op=(mpz_t*)malloc(sizeof(mpz_t) * num);
	for(i = 0; i < num; i++)
      	mpz_init(op[i]);
	return op;
}

mpz_t** Init_two (int num){

	int i, j;
	mpz_t** op = (mpz_t**)malloc(sizeof(mpz_t*) * (num));
	for(i = 0; i < num; i++)
	{
		op[i] = (mpz_t*)malloc(sizeof(mpz_t) * 2); 
		for(j = 0; j < 2; j++)
			mpz_init(op[i][j]); 
	} 
	return op;
}

void main(int argc, char* argv[]){

  struct timeval start;
  struct timeval pause;
  struct timeval end;
  unsigned long timer1;
  unsigned long timer2;
	//ciphertext_prg = malloc(16);
	int i,j;
	int op_type;
	char c = getopt( argc, argv, "w:r:");
	switch (c) {
	case 'w':
	  op_type = 0;
	  break;
	case 'r':
	  op_type = 1;
	  break;
	}
	int ele_num=atoi(argv[2]);
	//int party=atoi(argv[3]);
	//printf("this is main of party %d\n", party);

/**********************Init**********************************/
mpz_init (d);
mpz_init (d_base);
mpz_ui_pow_ui (d_base, 2, 127);
mpz_nextprime (d, d_base); //got a 128-bit prime

	int index[ELL]={0}; 
//	mpz_t read_sum; //used to store the final reading result;
//	mpz_t Mem[MEM_SIZE]; // we use this array to represent the memory.
    	mpz_t gamma, w_0, t_0;
//    	mpz_init(y_T);
//    	mpz_init(tt_T);   
	mpz_init(gamma);
//	mpz_init(beta);
	mpz_init(w_0);
	mpz_init(t_0);
//	mpz_init(read_sum);
    
//	mpz_t* Mem = Init_one (ele_num);

        mpz_t* sigma = Init_one (ELL+1);
	mpz_t** tau = Init_two (ELL+1);

	mpz_t* w_T = Init_one (ele_num);
	mpz_t* t_T = Init_one (ele_num);
	printf("this is init\n");

	unsigned char key_raw_sys[16]  = "ijduybfhcidorufh";
	uint8_t * key_raw = malloc(16);
	memcpy(key_raw, key_raw_sys, 16*sizeof(uint8_t));
	k_sys = offline_prg_keyschedule(key_raw);
	free(key_raw);

	ciphertext_1 = malloc(16);
	ciphertext_2 = malloc(16);
	ciphertext_3 = malloc(16);
	ciphertext_4 = malloc(16);
/**********************Init-end*******************************/




/**********MAKE UP SOME DATA**********************************/
//	for(i = 0; i < ele_num; i++)
//	  mpz_set_d(Mem[i],100);

//*Gen(100, beta, w_0, t_0, sigma, tau, gamma);
printf("this is after Gen\n");
/*******************Make up -end*******************************/
gettimeofday(&start,NULL);

Eval_gen(ele_num, gamma, w_0, t_0, sigma, tau, w_T, t_T, op_type);
gettimeofday(&pause,NULL);//stop timer here
timer1 = 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
printf("timer 1= %ld us\n",timer1);
// int p_last=Eval_gen(ele_num, w_0, t_0, sigma, tau, s_T, v_T, w_T, t_T, index);
printf("this is after eval_Gen\n");
/*
	if (op_type == 0) // 0 means the eval is executed for writing
	{
	  printf("writing\n");
	  //#pragma omp parallel for schedule(runtime)
	  for(i=0; i< ele_num; i++){
	  //printf("Thread# %d: i = %d\n", omp_get_thread_num(),i);	
	  // tran_index (i, index);
	  *Eval_write(sigma, tau, gamma, i, y_T, tt_T, s_T, v_T, w_T, t_T, p_last);
			mpz_add (Mem[i],Mem[i], y_T);
			mpz_mod (Mem[i], Mem[i], d);
		}

	}

	if (op_type == 1){ // 1 means the eval is executed for reading   
	  printf("reading\n");
	 	  //	   #pragma omp declare reduction (sum_r:mpz_t:omp_out=mpz_add(omp_out,omp_in)) initializer(mpz_init_set_si(omp_priv, 0)
													   // mpz_init_set_si(read_sum, 0);
												   //		#pragma omp parallel for reduction(sum_r:read_sum)  schedule(runtime)
	  printf("this plast %d", p_last);
	  for(i=0; i< ele_num; i++){
	  //printf("Thread# %d: i = %d\n", omp_get_thread_num(),i);
	  //printf("reading %d\n",i);
	  *Eval_read(sigma, tau, gamma, i, y_T, tt_T, s_T, v_T, w_T, t_T, p_last);

	  //printf("after reading %d\n",i);
	  mpz_addmul(read_sum, Mem[i], tt_T);
	  mpz_mod (read_sum, read_sum, d);
	  }

	}

	/************Free***************/
//    	mpz_clear(y_T);
//    	mpz_clear(tt_T);
	mpz_clear(gamma);
	mpz_clear(d_base);
	mpz_clear(d);
//	mpz_clear(beta);
	mpz_clear(w_0);
	mpz_clear(t_0);
	free(ciphertext_1);
	free(ciphertext_2);
	free(ciphertext_3);
	free(ciphertext_4);
//	mpz_clear(read_sum);
//	for (i = 0; i < ele_num; i++) {
//   	 mpz_clear(Mem[i]);
//	}

	for(i = 0; i < ELL+1; i++){
		mpz_clear(sigma[i]);
		mpz_clear(*tau[i]); 
	}

	for(i=0;i<ele_num;i++)
	{
//	  mpz_clear(s_T[i]);
//	  mpz_clear(v_T[i]);
	  mpz_clear(w_T[i]);
	  mpz_clear(t_T[i]);
	}
	//free(ciphertext_prg);
	/************Free***************/

}
