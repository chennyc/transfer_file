#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <wmmintrin.h>
#include <tmmintrin.h>
#include <gmp.h> 
#include <omp.h>
#include <gcrypt.h>
//#include "Encryption.h"
#include "Network.h"
#include "floram_util.h"
#include "Computation.h"
#include "AESNI_EN.h"



extern mpz_t d, d_base;
extern uint64_t * k_sys;
extern uint64_t * k1_prg;
extern uint64_t * k2_prg;
extern uint64_t * k3_prg;
extern uint8_t * plaintext_prg_k1;
extern uint8_t * plaintext_prg_k2;
extern uint8_t * plaintext_prg_k3;
extern uint8_t * plaintext_sys;
extern uint8_t * ciphertext_prg; //should be malloc later
extern int ell;



//usage of the en/decrypt function:encrypt (plaintext, strlen ((char *)plaintext), ciphertext);







void prg_aes_ni(uint64_t * keyed_a, mpz_t alpha, uint8_t * plaintext_prg)
{
//uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
	offline_prg(ciphertext_prg, plaintext_prg, keyed_a);
	memcpy(plaintext_prg,ciphertext_prg,16*sizeof(uint8_t));
	mpz_import(alpha, 16, 1, sizeof(uint8_t), 0, 0, ciphertext_prg);
	//mpz_mod (alpha, alpha, d);
}




mpz_t* Init_one (int num){

	int i;
	mpz_t * op=(mpz_t*)malloc(sizeof(mpz_t) * num);
	for(i = 0; i < num; i++)
      	mpz_init(op[i]);
	return op;
}

mpz_t** Init_two (int num){

	int i, j;
	mpz_t** op = (mpz_t**)malloc(sizeof(mpz_t*) * (num));
	for(i = 0; i < num; i++)
	{
		op[i] = (mpz_t*)malloc(sizeof(mpz_t) * 2); 
		for(j = 0; j < 2; j++)
			mpz_init(op[i][j]); 
	} 
	return op;
}
/*
void init_mem(mpz_t* Mem, int seed)
{
	mpz_t seeds;
	mpz_init(seeds);
	mpz_set_d (seeds, seed);
 	gmp_randstate_t state;
	gmp_randinit_mt (state);
	gmp_randseed (state, seeds);
	int i;
	for(i=0;i<ELE_NUM;i++)
	{
		 mpz_urandomm (Mem[i], state, d);
	
	}
	mpz_clear(seeds);
	gmp_randclear(state);
}
*/
void convert_bit(int index, mpz_t * mpz_array, int ell)
{
	
	char bits[ell];
	int i;
	for(i = 0; i< ell; i++)
	{
		//strcpy(bits[i], 'a');
		bits[i] = 'a';
	}

	mpz_t storage;
	mpz_init (storage);
	mpz_set_ui(storage, index);
	mpz_get_str(bits, 2, storage);
	int tmp;
	for(i = ell - 1; i>=0; i--)
	{
		if(bits[i]=='a')
		{
			//strcpy(bits[i], '0');	
			bits[i] = '0';
		}
		else if((bits[i]!='1')&&(bits[i]!='0'))bits[i] = '0';
		
		tmp = bits[i] - '0';
		mpz_set_ui(mpz_array[ell-1-i], tmp);
		//printf("i[%d]:%d\n", i, tmp);

	}
	mpz_clear (storage);

}

void Gen_three(mpz_t* sigma_list, mpz_t gamma, mpz_t* tau0_list, mpz_t* tau1_list, mpz_t* fk_1, mpz_t* fk_2, mpz_t* fk_3, mpz_t beta_1, mpz_t beta_2, mpz_t beta_3, mpz_t* alpha1, mpz_t* alpha2, mpz_t* alpha3, int *neighfd, struct memberlist *p, 	struct memberlist *mp, uint64_t * k1_prg, uint64_t * k2_prg, uint64_t * k3_prg, uint64_t * k_sys, struct message *msgp, struct aesmessage *aesmsgp, __m128i *key_aesen)
{
	int j;
	struct timeval start;
	struct timeval pause;
	struct timeval end;

	unsigned long timer1;


        mpz_t w0_3, w0_1, w0_2;
	mpz_init (w0_3);
	mpz_init (w0_1);
	mpz_init (w0_2);


        mpz_t t0_3, t0_1, t0_2;
	mpz_init (t0_3);
	mpz_init (t0_1);
	mpz_init (t0_2);


	mpz_init_set_ui (t0_3, 0); //t0_1 = t for party 2
	mpz_init_set_ui (t0_1, 1);
	mpz_init_set_ui (t0_2, 0);
	//mpz_urandomm (w0_3, state, d); 
	//mpz_urandomm (w0_3, state, d);
	//mpz_urandomm (w0_1, state, d);//RandF()

	mpz_set(fk_3[0], w0_3);
	mpz_set(fk_2[0], w0_2);
	mpz_set(fk_1[0], w0_1);
	mpz_set(fk_3[1], t0_3);
	mpz_set(fk_2[1], t0_2);
	mpz_set(fk_1[1], t0_1);


        mpz_t sj0_3, sj0_1, sj0_2;
        mpz_t sj1_3, sj1_1, sj1_2;
	mpz_init (sj0_3);
	mpz_init (sj0_1);
	mpz_init (sj0_2);
	mpz_init (sj1_3);
	mpz_init (sj1_1);
	mpz_init (sj1_2);

        mpz_t sjal_3, sjal_1, sjal_2; //s^j_alpha
        mpz_t sjhal_3, sjhal_1,  sjhal_2;
	mpz_init (sjal_3);
	mpz_init (sjal_1);
	mpz_init (sjal_2);
	mpz_init (sjhal_3);
	mpz_init (sjhal_1);
	mpz_init (sjhal_2);

        mpz_t vj0_3, vj0_1, vj0_2;
        mpz_t vj1_3, vj1_1, vj1_2;
	mpz_init (vj0_3);
	mpz_init (vj0_1);
	mpz_init (vj0_2);
	mpz_init (vj1_3);
	mpz_init (vj1_1);
	mpz_init (vj1_2);

        mpz_t vjal_3, vjal_1, vjal_2; //v^j_alpha
	mpz_init (vjal_3);
	mpz_init (vjal_1);
	mpz_init (vjal_2);
	
        mpz_t tauj0_3, tauj0_1, tauj0_2;
        mpz_t tauj1_3, tauj1_1, tauj1_2;
	mpz_init (tauj0_3);
	mpz_init (tauj0_1);
	mpz_init (tauj0_2);
	mpz_init (tauj1_3);
	mpz_init (tauj1_1);
	mpz_init (tauj1_2);


        mpz_t tau0, tau1; //tau^j_0,1
	mpz_init (tau0);
	mpz_init (tau1);

        mpz_t taujal_3, taujal_1, taujal_2; //tau^j_alpha
	mpz_init (taujal_3);
	mpz_init (taujal_1);
	mpz_init (taujal_2);

        mpz_t u_3, u_1, u_2; //u
	mpz_init (u_3);
	mpz_init (u_1);
	mpz_init (u_2);

        mpz_t sigma;
	mpz_init (sigma);

        mpz_t tmp1,tmp2, tmp3;
	mpz_init (tmp1);
	mpz_init (tmp2);
	mpz_init (tmp3);

  char msgbuffer1[64*sizeof(uint8_t)];
  char msgbuffer2[16*sizeof(uint8_t)];
  uint8_t * tmp_buf = malloc(16);

	//gmp_randstate_t prg_state;
  switch(p->party_no) //connect to each other
    {
    case 1:	setconnect_a(mp,msgp,neighfd);
	break;
    case 2:	setconnect_b(mp,msgp,neighfd);
	break;
    case 3:	setconnect_c(mp,msgp,neighfd);
	break;
    }

  switch(p->party_no)
    {
    case 1://this is a=1

	//setconnect_a(mp,msgp,neighfd);

	gettimeofday(&start,NULL); //start timer here
	prg_aes_ni(k2_prg, w0_2, plaintext_prg_k2);
	prg_aes_ni(k3_prg, w0_3, plaintext_prg_k3);

	for(j=0;j<ell;j++)
	{
		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_2);
		prg_aes_ni(k_sys, sj0_2, plaintext_sys);
		prg_aes_ni(k_sys, vj0_2, plaintext_sys);
		prg_aes_ni(k_sys, sj1_2, plaintext_sys);
		prg_aes_ni(k_sys, vj1_2, plaintext_sys);

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_3);
		prg_aes_ni(k_sys, sj0_3, plaintext_sys);
		prg_aes_ni(k_sys, vj0_3, plaintext_sys);
		prg_aes_ni(k_sys, sj1_3, plaintext_sys);
		prg_aes_ni(k_sys, vj1_3, plaintext_sys);
		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_3);//prg wj-1_[3]

		//mpz_urandomm (sj0_3, prg_state, d); 
		//mpz_urandomm (vj0_3, prg_state, d); 
		//mpz_urandomm (sj1_3, prg_state, d); 
		//mpz_urandomm (vj1_3, prg_state, d); 
		mpz_sub (u_2, sj1_2, sj0_2);
		mpz_mod (u_2, u_2, d);

		mpz_sub (u_3, sj1_3, sj0_3);
		mpz_mod (u_3, u_3, d);

		//threemultip(neighfd, alpha2[j], alpha3[j], sj1_2, sj1_3, u_2, u_3);
		//threemultip(neighfd, u_2, u_3, alpha2[j], alpha3[j], u_2, u_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen);
		mpz_addmul (tmp1, u_2, alpha2[j]);		
		mpz_addmul (tmp1, u_2, alpha3[j]);
		mpz_addmul (tmp1, u_3, alpha2[j]);
		prg_aes_ni(k2_prg, tmp2, plaintext_prg_k2);
		mpz_add (tmp1, tmp1, tmp2);
		prg_aes_ni(k3_prg, tmp2, plaintext_prg_k3);
		mpz_sub (tmp1, tmp1, tmp2);
		mpz_set (sjhal_1, tmp1);
					
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, tmp1);
	memcpy(msgbuffer1, tmp_buf, 16*sizeof(uint8_t));
	memcpy(msgbuffer2, tmp_buf, 16*sizeof(uint8_t));
		mpz_sub (vjal_2, vj1_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		mpz_sub (vjal_3, vj1_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);
		//threemultip(neighfd, vjal_2, vjal_3, alpha2[j], alpha3[j], vjal_2, vjal_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen);
		mpz_addmul (tmp1, vjal_2, alpha2[j]);		
		mpz_addmul (tmp1, vjal_2, alpha3[j]);
		mpz_addmul (tmp1, vjal_3, alpha2[j]); //tmp1 is v
		prg_aes_ni(k3_prg, vjal_3, plaintext_prg_k3);//vjal_3 is v_3
		mpz_sub (vjal_2, tmp1, vjal_3);//vjal_2 is v_2
						
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, vjal_2);
	memcpy(msgbuffer1+16, tmp_buf, 16*sizeof(uint8_t));

		prg_aes_ni(k2_prg, tmp1, plaintext_prg_k2);
		mpz_add (vjal_2, tmp1, vjal_2);

		mpz_add (u_2, vj0_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		//mpz_add_ui (u_2, u_2, 0); //1_2 = 1_3 =0, 1_1 =1
		//mpz_mod (u_2, u_2, d);
		mpz_add (u_3, vj0_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		//mpz_add_ui (u_3, u_3, 0);
		//mpz_mod (u_3, u_3, d);
		mpz_add (tau0, u_3, u_2);//tau0 still needds u_1 from 2
					
						
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, u_3);
	memcpy(msgbuffer1+32, tmp_buf, 16*sizeof(uint8_t));

		mpz_add (u_2, vj1_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add (u_3, vj1_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		mpz_add (tau1, u_3, u_2);//tau1 still needds u_1 from 2
					
						
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, u_3);
	memcpy(msgbuffer1+48, tmp_buf, 16*sizeof(uint8_t));
	aes128_enc(key_aesen,msgbuffer1,msgbuffer1);
	aes128_enc(key_aesen,msgbuffer2,msgbuffer2);

  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=12;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[1],msgbuffer2,16*sizeof(uint8_t),0);

  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=13;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[3],msgbuffer1,64*sizeof(uint8_t),0);

  memset(msgbuffer1,0,64*sizeof(uint8_t));
  memset(msgbuffer2,0,16*sizeof(uint8_t));
  recv(neighfd[2],msgbuffer1,64*sizeof(uint8_t),0 );
  recv(neighfd[4],msgbuffer2,16*sizeof(uint8_t),0 );
	aes128_dec(key_aesen,msgbuffer1,msgbuffer1);
	aes128_dec(key_aesen,msgbuffer2,msgbuffer2);

//	
	mpz_import(sjhal_3, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1); 
	mpz_import(sjhal_2, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer2); 

		mpz_add (sjhal_1, sjhal_1, sjhal_2);
		mpz_add (sjhal_1, sjhal_1, sjhal_3);
		mpz_add (sjal_2, sj1_2, sj0_2);
		//mpz_sub (sjal_2, sjal_2, 0);
		mpz_add (sjal_3, sj1_3, sj0_3);
		//mpz_sub (sjal_3, sjal_3, 0);
		mpz_mod (sjal_2, sjal_2, d);
		mpz_add (sjal_3, u_3, sj0_3);
		mpz_mod (sjal_3, sjal_3, d);
		mpz_mul (u_2, t0_2, sigma); 
		mpz_mod (u_2, u_2, d);
		mpz_mul (u_3, t0_3, sigma);
		mpz_mod (u_3, u_3, d);
		mpz_add (w0_2, sjal_2, u_2);
		mpz_mod (w0_2, w0_2, d);
		mpz_add (w0_3, sjal_3, u_3);
		mpz_mod (w0_3, w0_3, d);

//get vjal to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+16); 
		mpz_add (vjal_3, tmp1, vjal_3);	
//get u_3 to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+32); 
		mpz_add (tau0, tau0, tmp1);
//get u_3 to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+48); 
		mpz_add (tau1, tau1, tmp1);
/*		mpz_sub (sjhal_2, sj1_2, u_2);
		mpz_mod (sjhal_2, sjhal_2, d);
		mpz_sub (sjhal_3, sj1_3, u_3);
		mpz_mod (sjhal_3, sjhal_3, d);

		//sigma = threeopen(neighfd, sjhal_2, sjhal_3, msgp); //Open([s^{j,minus\alpha_j}])
		//gettimeofday(&open_start,NULL); //start timer here
		threeopen(neighfd, sjhal_2, sjhal_3, sigma, aesmsgp, key_aesen);
		//gettimeofday(&open_end,NULL); //start timer here
		//timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;

		mpz_add (u_2, vj0_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add_ui (u_2, u_2, 0); //1_2 = 1_3 =0, 1_1 =1
		mpz_mod (u_2, u_2, d);
		mpz_add (u_3, vj0_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		mpz_add_ui (u_3, u_3, 0);
		mpz_mod (u_3, u_3, d);
		
		//gettimeofday(&open_start,NULL); //start timer here
		threeopen(neighfd, u_2, u_3, tau0 , aesmsgp, key_aesen); //tau^{j,0}
		//gettimeofday(&open_end,NULL); //start timer here
		//timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;

		mpz_add (u_2, vj1_2, alpha2[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add (u_3, vj1_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		
		//gettimeofday(&open_start,NULL); //start timer here
		threeopen(neighfd, u_2, u_3, tau1, aesmsgp, key_aesen); //tau^{j,0}
		//gettimeofday(&open_end,NULL); //start timer here
		//timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;

		mpz_mul (u_2, t0_2, sigma); 
		mpz_mod (u_2, u_2, d);
		mpz_mul (u_3, t0_3, sigma);
		mpz_mod (u_3, u_3, d);

		mpz_add (w0_2, sjal_2, u_2);
		mpz_mod (w0_2, w0_2, d);
		mpz_add (w0_3, sjal_3, u_3);
		mpz_mod (w0_3, w0_3, d);		//[w^j]= ...


		mpz_sub (u_2, tau1, tau0);
		mpz_mod (u_2, u_2, d);
		//mpz_sub (u_2, vj1_2, vj0_2);
		//mpz_mod (u_2, u_2, d);
		mpz_mul (taujal_2, u_2, alpha2[j]); 
		mpz_mod (taujal_2, taujal_2, d);	
		mpz_mul (taujal_3, u_2, alpha3[j]);
		mpz_mod (taujal_3, taujal_3, d);

		mpz_add (taujal_2, taujal_2, tau0); //tau0_1 =tau0, and _2 =0
		mpz_mod (taujal_2, taujal_2, d);
		mpz_add_ui (taujal_3, taujal_3, 0);
		mpz_mod (taujal_3, taujal_3, d);
		threemultip(neighfd, u_2, u_3, t0_2, t0_3, taujal_2, taujal_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen); //u_1 = t^(j-1)_1 \times tau^{j,\alpha_j}_1
	

		mpz_sub (vjal_2, vj1_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		mpz_sub (vjal_3, vj1_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);
		threemultip(neighfd, vjal_2, vjal_3, alpha2[j], alpha3[j], vjal_2, vjal_3, k2_prg, k3_prg, 1,plaintext_prg_k2, plaintext_prg_k3, aesmsgp, key_aesen);

		mpz_add (vjal_2,  vjal_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		mpz_add (vjal_3,  vjal_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);


		mpz_add (t0_2,  vjal_2, u_2);
		mpz_mod (t0_2, t0_2, d);
		mpz_add (t0_3,  vjal_3, u_3);
		mpz_mod (t0_3, t0_3, d);
*/		
		mpz_set (sigma_list[j], sigma);
		mpz_set (tau0_list[j], tau0);
		mpz_set (tau1_list[j], tau1);
	}
	mpz_add (u_2, w0_2, beta_2);
	mpz_mod (u_2, u_2, d);
	mpz_add (u_3, w0_3, beta_3);
	mpz_mod (u_3, u_3, d);
	
//	gettimeofday(&open_start,NULL); //start timer here
	threeopen(neighfd, u_2, u_3, gamma, aesmsgp, key_aesen); //open \gama
//	gettimeofday(&open_end,NULL); //start timer here
//	timer_open += 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
//	printf("timer open= %ld us\n",timer_open);
/*
	gmp_printf ("fk_2: %Zd,\n %Zd \n",fk_2[0], fk_2[1]);
	gmp_printf ("fk_3: %Zd,\n %Zd \n", fk_3[0], fk_3[1]);
	for(j=0;j<ell;j++)
	{
		gmp_printf ("sigma %d: %Zd \n sigma %d: %Zd \n sigma %d: %Zd \n", j, sigma_list[j], j, tau0_list[j], j, tau1_list[j]);
	}
      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
*/
      break;

    case 2://this is b=3
	//setconnect_b(mp,msgp,neighfd);
	gettimeofday(&start,NULL); //start timer here
	prg_aes_ni(k1_prg, w0_1, plaintext_prg_k1);
	prg_aes_ni(k2_prg, w0_2, plaintext_prg_k2);


	for(j=0;j<ell;j++)
	{
		

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_1);//prg wj-1_[2]
		//set [w^{j-1}] as the key
/*		mpz_export(key_prg_w1, NULL, 1, sizeof(*key_prg_w1), 0, 0, w0_1);
		mpz_export(key_prg_w2, NULL, 1, sizeof(*key_prg_w2), 0, 0, w0_2);
		keyed_prg_w1 = offline_prg_keyschedule(key_prg_w2);
		keyed_prg_w2 = offline_prg_keyschedule(key_prg_w3);

		prg_aes_ni(keyed_prg_w1, sj0_1, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w1, vj0_1, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w1, sj1_1, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w1, vj1_1, plaintext_prg_wa);

		prg_aes_ni(keyed_prg_w2, sj0_2, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w2, vj0_2, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w2, sj1_2, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w2, vj1_2, plaintext_prg_wb);
*/
		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_1);
		prg_aes_ni(k_sys, sj0_1, plaintext_sys);
		prg_aes_ni(k_sys, vj0_1, plaintext_sys);
		prg_aes_ni(k_sys, sj1_1, plaintext_sys);
		prg_aes_ni(k_sys, vj1_1, plaintext_sys);

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_2);
		prg_aes_ni(k_sys, sj0_2, plaintext_sys);
		prg_aes_ni(k_sys, vj0_2, plaintext_sys);
		prg_aes_ni(k_sys, sj1_2, plaintext_sys);
		prg_aes_ni(k_sys, vj1_2, plaintext_sys);

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_2);//prg wj-1_[3]

		//mpz_urandomm (sj0_2, prg_state, d); 
		//mpz_urandomm (vj0_2, prg_state, d); 
		//mpz_urandomm (sj1_2, prg_state, d); 
		//mpz_urandomm (vj1_2, prg_state, d); 
		mpz_sub (u_1, sj1_1, sj0_1);
		mpz_mod (u_1, u_1, d);

		mpz_sub (u_2, sj1_2, sj0_2);
		mpz_mod (u_2, u_2, d);

		mpz_addmul (tmp1, u_3, alpha3[j]);		
		mpz_addmul (tmp1, u_3, alpha1[j]);
		mpz_addmul (tmp1, u_1, alpha3[j]);
		prg_aes_ni(k3_prg, tmp2, plaintext_prg_k3);
		mpz_add (tmp1, tmp1, tmp2);
		prg_aes_ni(k1_prg, tmp2, plaintext_prg_k1);
		mpz_sub (tmp1, tmp1, tmp2);
		mpz_set (sjhal_2, tmp1);
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, tmp1);
	memcpy(msgbuffer1, tmp_buf, 16*sizeof(uint8_t));
	memcpy(msgbuffer2, tmp_buf, 16*sizeof(uint8_t));
		mpz_sub (vjal_3, vj1_3, vj0_3);
		mpz_mod (vjal_3, vjal_3, d);
		mpz_sub (vjal_1, vj1_1, vj0_1);
		mpz_mod (vjal_1, vjal_1, d);
		//threemultip(neighfd, vjal_3, vjal_1, alpha3[j], alpha1[j], vjal_3, vjal_1, k3_prg, k1_prg, 1,plaintext_prg_k3, plaintext_prg_k1, aesmsgp, key_aesen);
		mpz_addmul (tmp1, vjal_3, alpha3[j]);		
		mpz_addmul (tmp1, vjal_3, alpha1[j]);
		mpz_addmul (tmp1, vjal_1, alpha3[j]); //tmp1 is v

		prg_aes_ni(k1_prg, vjal_1, plaintext_prg_k1);//vjal_1 is v_1

		//mpz_sub (vjal_3, tmp1, vjal_1);//vjal_3 is v_3

	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, vjal_3);

	memcpy(msgbuffer1+16, tmp_buf, 16*sizeof(uint8_t));

		prg_aes_ni(k3_prg, tmp1, plaintext_prg_k3);
		mpz_add (vjal_3, tmp1, vjal_3);

		mpz_add (u_3, vj0_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		//mpz_add_ui (u_3, u_3, 0); //1_3 = 1_1 =0, 1_1 =1
		//mpz_mod (u_3, u_3, d);
		mpz_add (u_1, vj0_1, alpha1[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add_ui (u_1, u_1, 1);
		mpz_mod (u_1, u_1, d);

		mpz_add (tau0, u_1, u_3);//tau0 still needds u_1 from 3
	

	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, u_1);
	memcpy(msgbuffer1+32, tmp_buf, 16*sizeof(uint8_t));
		mpz_add (u_3, vj1_3, alpha3[j]);
		mpz_mod (u_3, u_3, d);
		mpz_add (u_1, vj1_1, alpha1[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add (tau1, u_1, u_3);//tau1 still needds u_1 from 3

	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, u_1);
	memcpy(msgbuffer1+48, tmp_buf, 16*sizeof(uint8_t));
	aes128_enc(key_aesen,msgbuffer1,msgbuffer1);
	aes128_enc(key_aesen,msgbuffer2,msgbuffer2);

  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=12;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[1],msgbuffer2,16*sizeof(uint8_t),0);

  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=13;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[3],msgbuffer1,64*sizeof(uint8_t),0);

  memset(msgbuffer1,0,64*sizeof(uint8_t));
  memset(msgbuffer2,0,16*sizeof(uint8_t));
  recv(neighfd[4],msgbuffer1,64*sizeof(uint8_t),0 );
  recv(neighfd[2],msgbuffer2,16*sizeof(uint8_t),0 );
	aes128_dec(key_aesen,msgbuffer1,msgbuffer1);
	aes128_dec(key_aesen,msgbuffer2,msgbuffer2);

//
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer2); 
		mpz_set (sjhal_3, tmp1);
	mpz_import(sjhal_1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1); 
		mpz_add (sjhal_2, sjhal_1, sjhal_3);
		mpz_add (sjhal_2, sjhal_1, sjhal_1);

		mpz_add (sjal_3, sj1_3, sj0_3);
		//mpz_sub (sjal_3, sjal_3, 0);
		mpz_add (sjal_1, sj1_1, sj0_1);
		mpz_sub (sjal_1, sjal_1, sjhal_2);

		mpz_mod (sjal_3, sjal_3, d);
		mpz_add (sjal_1, u_1, sj0_1);
		mpz_mod (sjal_1, sjal_1, d);

		mpz_mul (u_3, t0_3, sigma); 
		mpz_mod (u_3, u_3, d);
		mpz_mul (u_1, t0_1, sigma);
		mpz_mod (u_1, u_1, d);

		mpz_add (w0_3, sjal_3, u_3);
		mpz_mod (w0_3, w0_3, d);
		mpz_add (w0_1, sjal_1, u_1);
		mpz_mod (w0_1, w0_1, d);		//[w^j]= ...

//get vjal to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+16); 
		mpz_add (vjal_1, tmp1, vjal_1);	
//get u_1 to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+32); 
		mpz_add (tau0, tau0, tmp1);
//get u_1 to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+48); 
		mpz_add (tau1, tau1, tmp1);
		
		mpz_set (sigma_list[j], sigma);
		mpz_set (tau0_list[j], tau0);
		mpz_set (tau1_list[j], tau1);
	}
	mpz_add (u_1, w0_1, beta_1);
	mpz_mod (u_1, u_1, d);
	mpz_add (u_2, w0_2, beta_2);
	mpz_mod (u_2, u_2, d);
	threeopen(neighfd, u_1, u_2, gamma, aesmsgp, key_aesen); //open \gama
/*
	gmp_printf ("fk_1: %Zd,\n %Zd \n",fk_1[0], fk_1[1]);
	gmp_printf ("fk_2: %Zd,\n %Zd \n", fk_2[0], fk_2[1]);
	for(j=0;j<ell;j++)
	{
		gmp_printf ("sigma %d: %Zd \n sigma %d: %Zd \n sigma %d: %Zd \n", j, sigma_list[j], j, tau0_list[j], j, tau1_list[j]);
	}
      p=mp;
      for(i=0;i<3;i++){
	printf("the fd for %d is %d \n", p->party_no, p->keepfd);
	p++;
      }
*/
      break;

    case 3://this is c=2

	//setconnect_c(mp,msgp,neighfd);

	gettimeofday(&start,NULL); //start timer here
	prg_aes_ni(k3_prg, w0_3, plaintext_prg_k3);
	prg_aes_ni(k1_prg, w0_1, plaintext_prg_k1);

	for(j=0;j<ell;j++)
	{
		

		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_3);//prg wj-1_[2]
		//set [w^{j-1}] as the key
/*		mpz_export(key_prg_w3, NULL, 1, sizeof(*key_prg_w3), 0, 0, w0_3);
		mpz_export(key_prg_w1, NULL, 1, sizeof(*key_prg_w1), 0, 0, w0_1);
		keyed_prg_w3 = offline_prg_keyschedule(key_prg_w3);
		keyed_prg_w1 = offline_prg_keyschedule(key_prg_w1);

		prg_aes_ni(keyed_prg_w3, sj0_3, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w3, vj0_3, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w3, sj1_3, plaintext_prg_wa);
		prg_aes_ni(keyed_prg_w3, vj1_3, plaintext_prg_wa);

		prg_aes_ni(keyed_prg_w1, sj0_1, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w1, vj0_1, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w1, sj1_1, plaintext_prg_wb);
		prg_aes_ni(keyed_prg_w1, vj1_1, plaintext_prg_wb);
*/
		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_3);
		prg_aes_ni(k_sys, sj0_3, plaintext_sys);
		prg_aes_ni(k_sys, vj0_3, plaintext_sys);
		prg_aes_ni(k_sys, sj1_3, plaintext_sys);
		prg_aes_ni(k_sys, vj1_3, plaintext_sys);

		mpz_export(plaintext_sys, NULL, 1, sizeof(*plaintext_sys), 0, 0, w0_1);
		prg_aes_ni(k_sys, sj0_1, plaintext_sys);
		prg_aes_ni(k_sys, vj0_1, plaintext_sys);
		prg_aes_ni(k_sys, sj1_1, plaintext_sys);
		prg_aes_ni(k_sys, vj1_1, plaintext_sys);
		//gmp_randinit_mt (prg_state);
		//gmp_randseed (prg_state, w0_1);//prg wj-1_[3]

		//mpz_urandomm (sj0_1, prg_state, d); 
		//mpz_urandomm (vj0_1, prg_state, d); 
		//mpz_urandomm (sj1_1, prg_state, d); 
		//mpz_urandomm (vj1_1, prg_state, d); 

		mpz_sub (u_3, sj1_3, sj0_3);
		mpz_mod (u_3, u_3, d);

		mpz_sub (u_1, sj1_1, sj0_1);
		mpz_mod (u_1, u_1, d);

				mpz_addmul (tmp1, u_1, alpha3[j]);		
		mpz_addmul (tmp1, u_1, alpha2[j]);
		mpz_addmul (tmp1, u_2, alpha3[j]);
		prg_aes_ni(k3_prg, tmp2, plaintext_prg_k3);
		mpz_add (tmp1, tmp1, tmp2);
		prg_aes_ni(k2_prg, tmp2, plaintext_prg_k2);
		mpz_sub (tmp1, tmp1, tmp2);
		mpz_set (sjhal_3, tmp1);
				
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, tmp1);
	memcpy(msgbuffer1, tmp_buf, 16*sizeof(uint8_t));
	memcpy(msgbuffer2, tmp_buf, 16*sizeof(uint8_t));

		mpz_sub (vjal_1, vj1_1, vj0_1);
		mpz_mod (vjal_1, vjal_1, d);
		mpz_sub (vjal_2, vj1_2, vj0_2);
		mpz_mod (vjal_2, vjal_2, d);
		//threemultip(neighfd, vjal_1, vjal_2, alpha3[j], alpha1[j], vjal_1, vjal_2, k3_prg, k1_prg, 1,plaintext_prg_k3, plaintext_prg_k1, aesmsgp, key_aesen);
		mpz_addmul (tmp1, vjal_1, alpha3[j]);		
		mpz_addmul (tmp1, vjal_1, alpha1[j]);
		mpz_addmul (tmp1, vjal_2, alpha3[j]); //tmp1 is v
		prg_aes_ni(k1_prg, vjal_2, plaintext_prg_k1);//vjal_2 is v_2
		mpz_sub (vjal_1, tmp1, vjal_2);//vjal_1 is v_1
				
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, vjal_1);
	memcpy(msgbuffer1+16, tmp_buf, 16*sizeof(uint8_t));


		prg_aes_ni(k3_prg, tmp1, plaintext_prg_k3);
		mpz_add (vjal_1, tmp1, vjal_1);


		mpz_add (u_1, vj0_1, alpha3[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add_ui (u_1, u_1, 1); //1_1 = 1_2 =0, 1_2 =1
		mpz_mod (u_1, u_1, d);
		mpz_add (u_2, vj0_2, alpha1[j]);
		mpz_mod (u_2, u_2, d);
		//mpz_add_ui (u_2, u_2, 0);
		mpz_mod (u_2, u_2, d);
		mpz_add (tau0, u_2, u_1);//tau0 still needds u_2 from 3

	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, u_2);
	memcpy(msgbuffer1+32, tmp_buf, 16*sizeof(uint8_t));

		mpz_add (u_1, vj1_1, alpha3[j]);
		mpz_mod (u_1, u_1, d);
		mpz_add (u_2, vj1_2, alpha1[j]);
		mpz_mod (u_2, u_2, d);
		mpz_add (tau1, u_2, u_1);//tau1 still needds u_2 from 3
					
	mpz_export(tmp_buf, NULL, 1, sizeof(*tmp_buf), 0, 0, u_2);
	memcpy(msgbuffer1+48, tmp_buf, 16*sizeof(uint8_t));
	aes128_enc(key_aesen,msgbuffer1,msgbuffer1);
	aes128_enc(key_aesen,msgbuffer2,msgbuffer2);

  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=12;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[1],msgbuffer2,16*sizeof(uint8_t),0);

  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=13;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[3],msgbuffer1,64*sizeof(uint8_t),0);

  memset(msgbuffer1,0,64*sizeof(uint8_t));
  memset(msgbuffer2,0,16*sizeof(uint8_t));
  recv(neighfd[4],msgbuffer1,64*sizeof(uint8_t),0 );
  recv(neighfd[2],msgbuffer2,16*sizeof(uint8_t),0 );
	aes128_dec(key_aesen,msgbuffer1,msgbuffer1);
	aes128_dec(key_aesen,msgbuffer2,msgbuffer2);

//
	mpz_import(sjhal_1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer2); 
	mpz_import(sjhal_2, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1); 
		mpz_add (sjhal_3, sjhal_2, sjhal_1);
		mpz_add (sjhal_3, sjhal_2, sjhal_2);

		mpz_add (sjal_3, sj1_1, sj0_1);
		mpz_sub (sjal_3, sjal_1, sjhal_3);
		mpz_add (sjal_2, sj1_2, sj0_2);
		//mpz_sub (sjal_2, sjal_2, 0);

		mpz_mod (sjal_1, sjal_1, d);
		mpz_add (sjal_2, u_2, sj0_2);
		mpz_mod (sjal_2, sjal_2, d);

		mpz_mul (u_1, t0_1, sigma); 
		mpz_mod (u_1, u_1, d);
		mpz_mul (u_2, t0_2, sigma);
		mpz_mod (u_2, u_2, d);

		mpz_add (w0_1, sjal_1, u_1);
		mpz_mod (w0_1, w0_1, d);
		mpz_add (w0_2, sjal_2, u_2);
		mpz_mod (w0_2, w0_2, d);		//[w^j]= ...


//get vjal to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+16); 
		mpz_add (vjal_2, tmp1, vjal_2);	
//get u_2 to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+32); 
		mpz_add (tau0, tau0, tmp1);
//get u_2 to tmp1
	mpz_import(tmp1, 16, 1, sizeof(uint8_t), 0, 0, msgbuffer1+48); 
		mpz_add (tau1, tau1, tmp1);
		
		mpz_set (sigma_list[j], sigma);
		mpz_set (tau0_list[j], tau0);
		mpz_set (tau1_list[j], tau1);
	}
	mpz_add (u_3, w0_3, beta_3);
	mpz_mod (u_3, u_3, d);
	mpz_add (u_1, w0_1, beta_1);
	mpz_mod (u_1, u_1, d);
	threeopen(neighfd, u_3, u_1, gamma, aesmsgp, key_aesen); //open \gama

      break;

    }
	gettimeofday(&pause,NULL);//stop timer here
	timer1 = 1000000 * (pause.tv_sec-start.tv_sec)+ pause.tv_usec-start.tv_usec;
	printf("timer of Gen= %ld us\n",timer1);
	shutdown(neighfd[1], 2);
	shutdown(neighfd[3], 2);
	mpz_clear(w0_1);
	mpz_clear(w0_2);
	mpz_clear(w0_3);
	mpz_clear(t0_1);
	mpz_clear(t0_2);
	mpz_clear(t0_3);
	mpz_clear(sj0_1);
	mpz_clear(sj0_2);
	mpz_clear(sj0_3);
	mpz_clear(sj1_1);
	mpz_clear(sj1_2);
	mpz_clear(sj1_3);
	mpz_clear(sjal_1);
	mpz_clear(sjal_2);
	mpz_clear(sjal_3);

	mpz_clear(sjhal_1);


	mpz_clear(sjhal_3);

	mpz_clear(sjhal_2);
	
	mpz_clear(vj0_1);
	mpz_clear(vj0_2);
	mpz_clear(vj0_3);
	mpz_clear(vj1_1);
	mpz_clear(vj1_2);

	mpz_clear(vj1_3);

	mpz_clear(vjal_1);
	mpz_clear(vjal_2);

	mpz_clear(vjal_3);
	mpz_clear(tauj0_1);

	mpz_clear(tauj0_2);
	mpz_clear(tauj0_3);

	mpz_clear(tauj1_1);
	mpz_clear(tauj1_2);

	mpz_clear(tauj1_3);
	mpz_clear(tau0);

	mpz_clear(tau1);

	mpz_clear(taujal_1);

	mpz_clear(taujal_2);

	mpz_clear(taujal_3);

	mpz_clear(u_1);

	mpz_clear(u_2);

	mpz_clear(u_3);

	mpz_clear(sigma);

	mpz_clear (tmp1);

	mpz_clear (tmp2);

	mpz_clear (tmp3);

	free(tmp_buf);



}

