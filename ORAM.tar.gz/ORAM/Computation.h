#ifndef Computation
#define Computation
#include "Network.h"
void threeopen(int *neighfd, mpz_t a, mpz_t b, mpz_t c, struct aesmessage *msgp, __m128i *key_schedule);

void threemultip(int *neighfd, mpz_t alpha, mpz_t beta, mpz_t a_a, mpz_t a_b, mpz_t b_a, mpz_t b_b, uint64_t * keyed_a,  uint64_t * keyed_b, int party, uint8_t * plaintext_prg_a, uint8_t * plaintext_prg_b, struct aesmessage *msgp,  __m128i *key_schedule);

#endif
