#ifndef Gen
#define Gen

#define ELE_NUM 32768
void prg_aes_ni(uint64_t * keyed_a, mpz_t alpha, uint8_t * plaintext_prg);

mpz_t* Init_one (int num);

mpz_t** Init_two (int num);

void convert_bit(int index, mpz_t * mpz_array, int ell);

void Gen_three(mpz_t* sigma_list, mpz_t gamma, mpz_t* tau0_list, mpz_t* tau1_list, mpz_t* fk_1, mpz_t* fk_2, mpz_t* fk_3, mpz_t beta_1, mpz_t beta_2, mpz_t beta_3, mpz_t* alpha1, mpz_t* alpha2, mpz_t* alpha3, int *neighfd, struct memberlist *p, 	struct memberlist *mp, uint64_t * k1_prg, uint64_t * k2_prg, uint64_t * k3_prg, uint64_t * k_sys, struct message *msgp, struct aesmessage *aesmsgp, __m128i *key_aesen);
#endif
