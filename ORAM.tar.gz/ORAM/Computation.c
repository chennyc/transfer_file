#include <gmp.h> 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>  
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <wmmintrin.h> 
#include "Computation.h"
#include "AESNI_EN.h"
#include "Gen.h"
extern mpz_t d, d_base;

void threeopen(int *neighfd, mpz_t a, mpz_t b, mpz_t c, struct aesmessage *msgp, __m128i *key_schedule) //b will be sent to next neighbor, c will be filled by the received value
{
	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;


	//char *buf;
	uint8_t  * buff = malloc(16);
	memset(buff,0,sizeof(*buff));
	mpz_export(buff, NULL, 1, sizeof(*buff), 0, 0, b);
	//mpz_get_str (buf, 10, b);
	//memcpy(msgp->mes, buff, 16);
	//mpz_t c;
	//mpz_init(c);
	//char msgbuf[sizeof(struct aesmessage)];

	
	/*   	
	int sendLegnth = strlen(buf) =1;
	message *Senddata = (message*)malloc()
*/
	//encrypt(buff, 16, msgp->mes);
	aes128_enc(key_schedule,buff,msgp->mes);
	//memcpy(msgp->mes, buff, 16*sizeof(char));
	//memset(msgbuf,0,sizeof(msgbuf));
	//memcpy(msgbuf,msgp,sizeof(*msgp)); 
	gettimeofday(&open_start,NULL); //start timer here
	send(neighfd[1],msgp,sizeof(msgp), 0);

	memset(msgp,0,sizeof(msgp));
        recv(neighfd[2],msgp,sizeof(msgp), 0);
	gettimeofday(&open_end,NULL);//stop timer here
	memset(buff,0,sizeof(*buff));
	//memset(msgp,0,sizeof(*msgp));
	//memcpy(msgp,msgbuf,sizeof(*msgp));
	//decrypt(msgp->mes, 16, buff);
	aes128_dec(key_schedule,msgp->mes,buff);	
	//memcpy(buff, msgp->mes, 16*sizeof(char));
	mpz_import(c, 16, 1, sizeof(*buff), 0, 0, buff);
	
	mpz_add (c, c, a);
	mpz_mod (c, c, d);
	mpz_add (c, c, b);
	mpz_mod (c, c, d);

	free(buff);
	//return c;

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("timer of open= %ld us\n",timer1);
}

void threemultip(int *neighfd, mpz_t alpha, mpz_t beta, mpz_t a_a, mpz_t a_b, mpz_t b_a, mpz_t b_b, uint64_t * keyed_a,  uint64_t * keyed_b, int party, uint8_t * plaintext_prg_a, uint8_t * plaintext_prg_b, struct aesmessage *msgp, __m128i *key_schedule)
{
	/*
	For party 1 (party=1), a_a=a_2, a_b=a_3, b_a=b_2, b_b=b_3,  keyed_a = k_2, keyed_b = k_3, alpha = c_2; beta = c_3
	For party 2 (party=3), a_a=a_3, a_b=a_1, b_a=b_3, b_b=b_1,  keyed_a = k_3, keyed_b = k_1, u=v, alpha = c_3; beta = c_2
	For party 3 (party=2), a_a=a_1, a_b=a_2, b_a=b_1, b_b=b_2,  keyed_a = k_1, keyed_b = k_2, w=v, alpha = c_1; beta = c_2
	*/
	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;


	mpz_t g_a;
	mpz_init(g_a);
	mpz_t g_b;
	mpz_init(g_b);
	mpz_t v;
	mpz_init(v);
	mpz_t v_a;
	mpz_init(v_a);
	mpz_t v_b;
	mpz_init(v_b);

	//prg_aes_ni(keyed_a, g_a);
	//mpz_mod (g_a, g_a, d);
	prg_aes_ni(keyed_b, v_b, plaintext_prg_b); //got v_3 for 1, u_1 for 2, w_2 for 3
	mpz_mod (v_b, v_b, d);
	mpz_mul (g_a, a_a, b_a);
	mpz_mod (g_a, g_a, d);
	mpz_mul (g_b, a_a, b_b);
	mpz_mod (g_b, g_b, d);
	mpz_mul (v, a_b, b_a);
	mpz_mod (v, v, d);
	mpz_add (v, v, g_a);	
	mpz_add (v, v, g_b);
	mpz_mod (v, v, d); // got v/u/w

	mpz_sub(v_a, v, v_b);
	mpz_mod (v_a, v_b, d); //got v_2 for 1, u_3 for 2, w_1 for 3


	uint8_t  * buff = malloc(16);
	mpz_export(buff, NULL, 1, sizeof(*buff), 0, 0, v_a);
	aes128_enc(key_schedule,buff,msgp->mes);
	//memcpy(msgp->mes, buff, 16);
	//char msgbuf[sizeof(struct message)];
	//encrypt(buff, 16, msgp->mes);
	//memcpy(msgp->mes, buff, 16*sizeof(char));
	//memset(msgbuf,0,sizeof(msgbuf));
	//memcpy(msgbuf,msgp,sizeof(*msgp)); 
	gettimeofday(&open_start,NULL); //start timer here
	send(neighfd[1],msgp,sizeof(msgp), 0);

	memset(buff,0,sizeof(*buff));
	memset(msgp,0,sizeof(msgp));
        recv(neighfd[2],msgp,sizeof(msgp), 0);
	gettimeofday(&open_end,NULL);//stop timer here
	//memset(msgp,0,sizeof(*msgp));
	//memcpy(msgp,msgbuf,sizeof(*msgp));
	//decrypt(msgp->mes, 16, buff);
	aes128_dec(key_schedule,msgp->mes,buff);
	//memcpy(buff, msgp->mes, 16*sizeof(char));
	mpz_import(g_a, 16, 1, sizeof(*buff), 0, 0, buff); //g_a is used to store the value received from neighbor; u_3 for p_1; w_1 for p_2; v_2 for p_3

	prg_aes_ni(keyed_a, g_b, plaintext_prg_a);
	mpz_mod (g_b, g_b, d); // got g_2.next for 1, ...

	mpz_add (alpha, v_a, g_b);
	mpz_mod (alpha, alpha, d);

	mpz_add (beta, v_b, g_a);
	mpz_mod (beta, beta, d);
	
	mpz_clear(g_a);
	mpz_clear(g_b);
	mpz_clear(v);
	mpz_clear(v_a);
	mpz_clear(v_b);

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("timer of multi= %ld us\n",timer1);
}
