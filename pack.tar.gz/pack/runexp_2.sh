echo "./tl1_5 2 runtime-config private-2.pem 1 1 ./tl_file/tl5_share2 tl5_out"
eval "./tl1_5 2 runtime-config private-2.pem 1 1 ./tl_file/tl5_share2 tl5_out"
sleep 4

echo "./tl1_6 2 runtime-config private-2.pem 1 1 ./tl_file/tl6_share2 tl6_out"
eval "./tl1_6 2 runtime-config private-2.pem 1 1 ./tl_file/tl6_share2 tl6_out"
sleep 4

echo "./tl1_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
eval "./tl1_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
sleep 4

echo "./tl1_8 2 runtime-config private-2.pem 1 1 ./tl_file/tl8_share2 tl8_out"
eval "./tl1_8 2 runtime-config private-2.pem 1 1 ./tl_file/tl8_share2 tl8_out"
sleep 4

echo "./tl1_9 2 runtime-config private-2.pem 1 1 ./tl_file/tl9_share2 tl9_out"
eval "./tl1_9 2 runtime-config private-2.pem 1 1 ./tl_file/tl9_share2 tl9_out"
sleep 4

echo "./tl1_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
eval "./tl1_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
sleep 4

echo "./tl1_11 2 runtime-config private-2.pem 1 1 ./tl_file/tl11_share2 tl11_out"
eval "./tl1_11 2 runtime-config private-2.pem 1 1 ./tl_file/tl11_share2 tl11_out"
sleep 4

echo "./tl1_12 2 runtime-config private-2.pem 1 1 ./tl_file/tl12_share2 tl12_out"
eval "./tl1_12 2 runtime-config private-2.pem 1 1 ./tl_file/tl12_share2 tl12_out"
sleep 4

echo "./tl1_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
eval "./tl1_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
sleep 4

echo "./tl1_14 2 runtime-config private-2.pem 1 1 ./tl_file/tl14_share2 tl14_out"
eval "./tl1_14 2 runtime-config private-2.pem 1 1 ./tl_file/tl14_share2 tl14_out"
sleep 4

echo "./tl1_15 2 runtime-config private-2.pem 1 1 ./tl_file/tl15_share2 tl15_out"
eval "./tl1_15 2 runtime-config private-2.pem 1 1 ./tl_file/tl15_share2 tl15_out"
sleep 4

echo "./tl1_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
eval "./tl1_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
sleep 4

echo "./tl1_17 2 runtime-config private-2.pem 1 1 ./tl_file/tl17_share2 tl17_out"
eval "./tl1_17 2 runtime-config private-2.pem 1 1 ./tl_file/tl17_share2 tl17_out"
sleep 4
