echo "./tl1_5 3 runtime-config private-3.pem 1 1 ./tl_file/tl5_share3 tl5_out"
eval "./tl1_5 3 runtime-config private-3.pem 1 1 ./tl_file/tl5_share3 tl5_out"
sleep 1

echo "./tl1_6 3 runtime-config private-3.pem 1 1 ./tl_file/tl6_share3 tl6_out"
eval "./tl1_6 3 runtime-config private-3.pem 1 1 ./tl_file/tl6_share3 tl6_out"
sleep 1

echo "./tl1_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
eval "./tl1_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
sleep 1

echo "./tl1_8 3 runtime-config private-3.pem 1 1 ./tl_file/tl8_share3 tl8_out"
eval "./tl1_8 3 runtime-config private-3.pem 1 1 ./tl_file/tl8_share3 tl8_out"
sleep 1

echo "./tl1_9 3 runtime-config private-3.pem 1 1 ./tl_file/tl9_share3 tl9_out"
eval "./tl1_9 3 runtime-config private-3.pem 1 1 ./tl_file/tl9_share3 tl9_out"
sleep 1

echo "./tl1_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
eval "./tl1_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
sleep 1

echo "./tl1_11 3 runtime-config private-3.pem 1 1 ./tl_file/tl11_share3 tl11_out"
eval "./tl1_11 3 runtime-config private-3.pem 1 1 ./tl_file/tl11_share3 tl11_out"
sleep 1

echo "./tl1_12 3 runtime-config private-3.pem 1 1 ./tl_file/tl12_share3 tl12_out"
eval "./tl1_12 3 runtime-config private-3.pem 1 1 ./tl_file/tl12_share3 tl12_out"
sleep 1

echo "./tl1_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
eval "./tl1_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
sleep 1

echo "./tl1_14 3 runtime-config private-3.pem 1 1 ./tl_file/tl14_share3 tl14_out"
eval "./tl1_14 3 runtime-config private-3.pem 1 1 ./tl_file/tl14_share3 tl14_out"
sleep 1

echo "./tl1_15 3 runtime-config private-3.pem 1 1 ./tl_file/tl15_share3 tl15_out"
eval "./tl1_15 3 runtime-config private-3.pem 1 1 ./tl_file/tl15_share3 tl15_out"
sleep 1

echo "./tl1_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
eval "./tl1_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
sleep 1

echo "./tl1_17 3 runtime-config private-3.pem 1 1 ./tl_file/tl17_share3 tl17_out"
eval "./tl1_17 3 runtime-config private-3.pem 1 1 ./tl_file/tl17_share3 tl17_out"
sleep 1
