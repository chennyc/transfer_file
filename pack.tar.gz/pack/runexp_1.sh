echo "./tl1_5 1 runtime-config private-1.pem 1 1 ./tl_file/tl5_share1 tl5_out"
eval "./tl1_5 1 runtime-config private-1.pem 1 1 ./tl_file/tl5_share1 tl5_out"
sleep 7

touch ./flag/1-5


echo "./tl1_6 1 runtime-config private-1.pem 1 1 ./tl_file/tl6_share1 tl6_out"
eval "./tl1_6 1 runtime-config private-1.pem 1 1 ./tl_file/tl6_share1 tl6_out"
sleep 7

touch ./flag/1-6

echo "./tl1_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
eval "./tl1_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
sleep 7

touch ./flag/1-7

echo "./tl1_8 1 runtime-config private-1.pem 1 1 ./tl_file/tl8_share1 tl8_out"
eval "./tl1_8 1 runtime-config private-1.pem 1 1 ./tl_file/tl8_share1 tl8_out"
sleep 7

touch ./flag/1-8

echo "./tl1_9 1 runtime-config private-1.pem 1 1 ./tl_file/tl9_share1 tl9_out"
eval "./tl1_9 1 runtime-config private-1.pem 1 1 ./tl_file/tl9_share1 tl9_out"
sleep 7

touch ./flag/1-9

echo "./tl1_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
eval "./tl1_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
sleep 7

touch ./flag/1-10


echo "./tl1_11 1 runtime-config private-1.pem 1 1 ./tl_file/tl11_share1 tl11_out"
eval "./tl1_11 1 runtime-config private-1.pem 1 1 ./tl_file/tl11_share1 tl11_out"
sleep 7

touch ./flag/1-11


echo "./tl1_12 1 runtime-config private-1.pem 1 1 ./tl_file/tl12_share1 tl12_out"
eval "./tl1_12 1 runtime-config private-1.pem 1 1 ./tl_file/tl12_share1 tl12_out"
sleep 7

touch ./flag/1-12


echo "./tl1_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
eval "./tl1_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
sleep 7

touch ./flag/1-13


echo "./tl1_14 1 runtime-config private-1.pem 1 1 ./tl_file/tl14_share1 tl14_out"
eval "./tl1_14 1 runtime-config private-1.pem 1 1 ./tl_file/tl14_share1 tl14_out"
sleep 7

touch ./flag/1-14


echo "./tl1_15 1 runtime-config private-1.pem 1 1 ./tl_file/tl15_share1 tl15_out"
eval "./tl1_15 1 runtime-config private-1.pem 1 1 ./tl_file/tl15_share1 tl15_out"
sleep 7

touch ./flag/1-15


echo "./tl1_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
eval "./tl1_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
sleep 7

touch ./flag/1-16


echo "./tl1_17 1 runtime-config private-1.pem 1 1 ./tl_file/tl17_share1 tl17_out"
eval "./tl1_17 1 runtime-config private-1.pem 1 1 ./tl_file/tl17_share1 tl17_out"
sleep 7
