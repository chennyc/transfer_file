echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_5_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_5_utility"
file="./flag/1-5"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_6_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_6_utility"
file="./flag/1-6"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_7_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_7_utility"
file="./flag/1-7"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_8_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_8_utility"
file="./flag/1-8"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_9_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_9_utility"
file="./flag/1-9"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_10_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_10_utility"
file="./flag/1-10"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_11_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_11_utility"
file="./flag/1-11"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_12_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_12_utility"
file="./flag/1-12"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_13_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_13_utility"
file="./flag/1-13"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_14_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_14_utility"
file="./flag/1-14"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_15_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_15_utility"
file="./flag/1-15"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_16_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_16_utility"
file="./flag/1-16"
while [ ! -f "$file" ]
do
	eval "cd ."
done

sleep 1

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_17_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1_17_utility"

