#!/bin/bash
cd runtime/ee_pthreads
make all

